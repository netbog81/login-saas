# @curandis/auth-core

Shared authentication & tenant resolution library for Curandis microservices.

## Cosa fornisce

- **`JwksService`** — validazione JWT emessi da Keycloak (scarica le chiavi pubbliche JWKS all'avvio)
- **`TenantResolverService`** — estrae tenant alias da header/subdomain e orgId/ruoli dal JWT
- **`CurandisTenantContextMiddleware`** — middleware che valida JWT, risolve tenant, ottiene DataSource, popola `req.tenantContext`
- **`@TenantCtx()`** — decorator parametro per iniettare il contesto tenant nei controller
- **`CurandisTenantContext`** — interfaccia del contesto (userId, email, roles, tenantAlias, orgId, requestId)

## Dipendenze peer

- `@curandis/tenant-datasource` — per ottenere il DataSource del tenant
- `@nestjs/common`
- `express`
- `jose` — validazione JWT

## Uso

```typescript
import { Module, MiddlewareConsumer, NestModule } from '@nestjs/common';
import { AuthCoreModule, CurandisTenantContextMiddleware } from '@curandis/auth-core';

@Module({
  imports: [
    // ... TenantDataSourceModule.forRoot(...)
    AuthCoreModule.forRoot({
      keycloakUrl: process.env.KEYCLOAK_URL,
      keycloakRealm: 'curandis',
      keycloakClientId: 'curandis-app-angular',
      tenantResolver: {
        fromHeader: 'x-tenant-alias',
        fromSubdomainPatterns: [/^registry\.([^.]+)\.curandis\.cloud$/],
        fromJwtClaim: 'organization',
      },
    }),
  ],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(CurandisTenantContextMiddleware)
      .exclude('health/(.*)', 'docs/(.*)')
      .forRoutes('*');
  }
}
```

Nei controller:

```typescript
import { TenantCtx, CurandisTenantContext } from '@curandis/auth-core';

@Controller('persons')
export class PersonsController {
  @Get(':id')
  findOne(@TenantCtx() ctx: CurandisTenantContext, @Param('id') id: string) {
    return this.service.findById(id, ctx.orgId);
  }
}
```

## Configurazione

### `keycloakUrl` (opzionale)
URL base di Keycloak. Default: `process.env.KEYCLOAK_URL || 'https://my.curandis.cloud'`.

### `keycloakRealm` (opzionale)
Realm Keycloak. Default: `process.env.KEYCLOAK_REALM || 'curandis'`.

### `keycloakClientId` (opzionale)
Client ID per estrarre ruoli da `resource_access`. Default: `process.env.KEYCLOAK_CLIENT_ID || 'curandis-app-angular'`.

### `tenantResolver` (obbligatorio)

| Campo | Default | Descrizione |
|---|---|---|
| `fromHeader` | `'x-tenant-alias'` | Nome header HTTP |
| `fromSubdomainPatterns` | `[]` | Regex applicate al hostname (il primo capture group è l'alias) |
| `fromJwtClaim` | `'organization'` | Claim JWT per l'alias |
| `fromJwtOrgIdClaim` | `'org_id'` | Claim JWT per l'UUID organizzazione |
| `defaultTenantForLocalhost` | `process.env.DEFAULT_TENANT` | Fallback per sviluppo locale |
| `nonTenantSubdomains` | `['api', 'auth', 'tenants', 'my', 'www']` | Sotto-domini che NON sono tenant |

## Build

```bash
npm install
npm run build
```
