# @curandis/encryption-core

Libreria di cifratura condivisa per i microservizi Curandis.

Fornisce:
- **`TransitEncryptionService`** — cifratura/decifratura via OpenBao Transit Engine (AES-256-GCM)
- **`BlindIndexService`** — calcolo hash HMAC-SHA256 deterministico via OpenBao, per ricerche su campi cifrati
- **Helper di normalizzazione** — funzioni standard per nomi, codici fiscali, email, telefoni

## Setup OpenBao (una tantum)

```bash
# Abilita transit engine
vault secrets enable -path=transit transit

# Chiave di cifratura (AES-256)
vault write -f transit/keys/<servizio>-data \
  type=aes256-gcm96 exportable=false deletion_allowed=false

# Chiave HMAC per blind index
vault write -f transit/keys/<servizio>-blind-index \
  type=hmac hash_algorithm=sha256 exportable=false
```

## Policy OpenBao richiesta

```hcl
path "transit/encrypt/<servizio>-data" { capabilities = ["update"] }
path "transit/decrypt/<servizio>-data" { capabilities = ["update"] }
path "transit/rewrap/<servizio>-data"  { capabilities = ["update"] }
path "transit/hmac/<servizio>-blind-index"   { capabilities = ["update"] }
path "transit/verify/<servizio>-blind-index" { capabilities = ["update"] }
```

## Uso in NestJS

```typescript
import { Module } from '@nestjs/common';
import { OpenbaoBaseModule, OpenbaoBaseService } from '@curandis/openbao-core';
import { EncryptionCoreModule } from '@curandis/encryption-core';

@Module({
  imports: [
    OpenbaoBaseModule.forRoot(openbaoService),
    EncryptionCoreModule.forRootAsync({
      useFactory: (openbao: OpenbaoBaseService) => ({
        openbaoAddr: process.env.OPENBAO_ADDR,
        // Espone il token corrente. OpenbaoBaseService gestisce rinnovo/rotazione.
        tokenProvider: () => (openbao as any).token,
      }),
      inject: [OpenbaoBaseService],
    }),
  ],
})
export class AppModule {}
```

> Nota: `OpenbaoBaseService` al momento tiene il token privato. Se non è accessibile tramite getter pubblico, implementa un adapter/wrapper.

### Cifratura

```typescript
constructor(private encryption: TransitEncryptionService) {}

async saveUser(name: string) {
  const result = await this.encryption.encrypt({
    keyName: 'registry-individual-data',
    plaintext: name,
  });
  // result.ciphertext: Buffer
  // result.keyVersion: 1
  // result.ciphertextString: 'vault:v1:...'

  await repo.save({
    nameCiphertext: result.ciphertext,
    nameKeyVersion: result.keyVersion,
  });
}

async loadUser(id: string) {
  const user = await repo.findOne({ where: { id } });
  const name = await this.encryption.decrypt({
    keyName: 'registry-individual-data',
    ciphertext: user.nameCiphertext,
  });
  return { id, name };
}
```

### Batch (più efficiente)

```typescript
const plains = await this.encryption.decryptBatch([
  { keyName: 'registry-individual-data', ciphertext: user.firstNameCiphertext },
  { keyName: 'registry-individual-data', ciphertext: user.lastNameCiphertext },
  { keyName: 'registry-individual-data', ciphertext: user.taxCodeCiphertext },
]);
// plains[0] = firstName, plains[1] = lastName, plains[2] = taxCode
```

### Blind index (ricerca su dati cifrati)

```typescript
import { normalizeName } from '@curandis/encryption-core';

// Scrittura: calcola e salva
const normalized = normalizeName('Mario'); // 'mario'
const bi = await this.blindIndex.compute({
  keyName: 'registry-blind-index',
  plaintext: normalized,
});
await repo.save({ firstNameBlindIndex: bi, ... });

// Lettura: stesso calcolo, poi query su colonna indicizzata
const searchNormalized = normalizeName(input.firstName);
const searchBi = await this.blindIndex.compute({
  keyName: 'registry-blind-index',
  plaintext: searchNormalized,
});
const results = await repo.find({ where: { firstNameBlindIndex: searchBi } });
```

### Rotazione chiave

```bash
# Dopo aver ruotato la chiave su OpenBao:
vault write -f transit/keys/registry-individual-data/rotate
```

```typescript
// Job batch di rewrap
const oldRows = await repo.find({
  where: { firstNameKeyVersion: LessThan(currentVersion) },
});
for (const row of oldRows) {
  const rewrapped = await this.encryption.rewrap({
    keyName: 'registry-individual-data',
    ciphertext: row.firstNameCiphertext,
  });
  row.firstNameCiphertext = rewrapped.ciphertext;
  row.firstNameKeyVersion = rewrapped.keyVersion;
  await repo.save(row);
}
```

## Normalizzazione

**IMPORTANTE:** il blind index non è "fuzzy matching". Richiede **esattamente lo stesso valore normalizzato** in scrittura e in lettura.

Usa sempre gli helper standard:

```typescript
import { normalize } from '@curandis/encryption-core';

normalize('Mario ', 'name');           // 'mario'
normalize('RSSMRA80A01H501Z', 'taxCode'); // 'RSSMRA80A01H501Z'
normalize('Mario@Example.com', 'email');  // 'mario@example.com'
normalize('+39 333 123 4567', 'phone');   // '+393331234567'
```

Se hai bisogno di normalizzazione custom, fallo **prima** di chiamare `compute()` ed essere certo di usare lo stesso algoritmo sia in write che in read.

## Build

```bash
npm install
npm run build
npm pack   # per generare tarball
```
