import { TemplateDocument, TemplatePageSettings, MergeFieldDef, TemplateCollectionDef, DynamicTableAttrs, DynamicTableColumn } from '@curandis/template-core';
export * from '@curandis/template-core';
import * as i0 from '@angular/core';
import { AfterViewInit, OnChanges, OnDestroy, EventEmitter, ElementRef, NgZone, ChangeDetectorRef, SimpleChanges } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';

interface MergeFieldGroup {
    name: string;
    fields: MergeFieldDef[];
}
/**
 * Editor WYSIWYG di template documento (TipTap + Angular Material).
 *
 * Componente RIUSABILE e autocontenuto: comunica solo via Input/Output,
 * nessuna dipendenza da servizi applicativi. La superficie di editing
 * riproduce il foglio A4 con le impostazioni di pagina applicate: ciò che si
 * vede è ciò che verrà stampato (il rendering usa lo stesso HTML/CSS di
 * @curandis/template-core).
 *
 * Con `collections` valorizzato l'editor abilita le tabelle dinamiche:
 * blocchi tabella le cui righe vengono generate dai dati (es. righe fattura),
 * con colori di sfondo alternati configurabili.
 */
declare class TemplateEditorComponent implements AfterViewInit, OnChanges, OnDestroy {
    private readonly zone;
    private readonly cdr;
    private readonly snackBar;
    /** Documento TipTap JSON iniziale (null → documento vuoto). */
    content: TemplateDocument | null;
    /** Impostazioni pagina (null → default). */
    pageSettings: Partial<TemplatePageSettings> | null;
    /** Campi dinamici disponibili per questo tipo di documento. */
    mergeFields: MergeFieldDef[];
    /**
     * Collezioni ripetibili disponibili (es. righe documento). Se vuoto, le
     * tabelle dinamiche non sono proposte (comportamento del clinico).
     */
    collections: TemplateCollectionDef[];
    contentChange: EventEmitter<TemplateDocument>;
    pageSettingsChange: EventEmitter<TemplatePageSettings>;
    editorHost?: ElementRef<HTMLElement>;
    pageEl?: ElementRef<HTMLElement>;
    /** Di quanti mm il contenuto sfora il primo foglio A4 (0 = ci sta). */
    overflowMm: number;
    /** Binding orfani nel documento (chiavi assenti dal catalogo corrente). */
    orphanCount: number;
    /**
     * Spazio (px) riservato in fondo a ogni pagina dal piè di pagina ripetuto:
     * in stampa è un blocco fisso, quindi riduce l'area utile del corpo.
     * Misurato dal DOM a ogni check (0 se il template non ha piè di pagina).
     */
    private footerReservePx;
    settings: TemplatePageSettings;
    readonly fontOptions: readonly {
        label: string;
        value: string;
    }[];
    /** Dimensioni (pt) selezionabili per il testo evidenziato. */
    readonly fontSizes: number[];
    private editor?;
    /** Indice del catalogo corrente per il check dei binding orfani. */
    private validFieldKeys;
    private validCollections;
    constructor(zone: NgZone, cdr: ChangeDetectorRef, snackBar: MatSnackBar);
    get fieldGroups(): MergeFieldGroup[];
    get pagePadding(): string;
    /** Fondo dell'area utile del primo foglio, rispetto al bordo della pagina. */
    get pageBreakTop(): string;
    /**
     * Misura quanto il contenuto sfora l'area utile del primo foglio.
     * La superficie di editing è a scorrimento continuo (`min-height: 297mm`),
     * quindi senza questo controllo un documento troppo lungo sembra entrare
     * in una pagina e poi in stampa se ne prende due.
     */
    private scheduleOverflowCheck;
    /**
     * Estensione che marca con la classe `tpl-orphan` i binding la cui chiave
     * non esiste nel catalogo della categoria corrente (mergeField, blocco
     * condizionale, tabella dinamica). Solo editing: alla risoluzione i nodi
     * orfani degradano a "—"/tabella vuota (resolveTemplate, template-core).
     */
    private orphanHighlightExtension;
    private buildOrphanDecorations;
    /**
     * Aggiorna il contatore del banner fuori dal ciclo di render di
     * ProseMirror (decorations() è chiamata durante l'update della view,
     * fuori zona: mutare lo stato Angular lì dentro sarebbe fragile).
     */
    private syncOrphanCount;
    /**
     * Stile del blocco logo: la stessa funzione usata dal rendering di stampa
     * (template-core → logoHtml).
     */
    get logoBlockStyle(): Record<string, string>;
    get currentBlock(): string;
    /** Dimensione del testo alla selezione corrente ('' = eredita dal foglio). */
    get currentFontSize(): string;
    /** Colore del testo alla selezione corrente (default: colore del foglio). */
    get currentTextColor(): string;
    /** Evidenziazione (sfondo testo) alla selezione corrente. */
    get currentHighlight(): string;
    /** Sfondo del paragrafo corrente (banda a tutta larghezza). */
    get currentBandColor(): string;
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    isActive(what: string): boolean;
    isAligned(dir: string): boolean;
    cmd(action: string): void;
    align(dir: 'left' | 'center' | 'right' | 'justify'): void;
    /** Applica la dimensione carattere al testo selezionato ('' = ripristina). */
    setFontSize(size: string): void;
    setTextColor(event: Event): void;
    setHighlight(event: Event): void;
    setBandColor(event: Event): void;
    /** Rimuove colore testo, evidenziazione e sfondo riga dalla selezione. */
    clearColors(): void;
    get currentRuleColor(): string;
    get currentRuleThickness(): number;
    setRuleColor(event: Event): void;
    resetRuleColor(): void;
    setRuleThickness(thickness: number): void;
    setBlock(block: string): void;
    insertField(field: MergeFieldDef): void;
    /** Elimina il nodo selezionato (linea, immagine o tabella dinamica). */
    deleteSelectedNode(): void;
    /** Attributi del blocco condizionale attivo (null se il cursore è fuori). */
    get conditionalAttrs(): {
        field: string;
        mode: 'notEmpty' | 'empty';
        label: string;
    } | null;
    /** Label di un campo cercandolo in tutti i gruppi (per l'etichetta blocco). */
    labelForAnyField(key: string): string;
    insertConditionalBlock(): void;
    patchConditional(patch: Partial<{
        field: string;
        mode: string;
        label: string;
    }>): void;
    /** Elimina il blocco condizionale (contenuto incluso). */
    deleteConditionalBlock(): void;
    /** Rimuove SOLO il wrapper condizionale: il contenuto resta nel documento. */
    unwrapConditional(): void;
    /** Sezione pagina in cui si trova il cursore (null se nel corpo). */
    get activeSection(): 'pageHeader' | 'pageFooter' | null;
    /** Posizione e dimensione del nodo sezione nel documento (null se assente). */
    private findSection;
    /**
     * Bottone toolbar: crea la sezione se manca, altrimenti porta il cursore
     * al suo interno (l'eliminazione è nella barra contestuale, esplicita).
     */
    toggleSection(name: 'pageHeader' | 'pageFooter'): void;
    /** Elimina la sezione (contenuto incluso). */
    deleteSection(name: 'pageHeader' | 'pageFooter'): void;
    /** Attributi della tabella dinamica selezionata (null se non selezionata). */
    get tableAttrs(): DynamicTableAttrs | null;
    /** Definizione della collezione usata dalla tabella selezionata. */
    get tableCollectionFields(): MergeFieldDef[];
    labelForField(key: string): string;
    insertDynamicTable(): void;
    patchTable(patch: Partial<DynamicTableAttrs>): void;
    setTableColor(attr: 'headerBg' | 'headerColor' | 'oddRowBg' | 'evenRowBg' | 'borderColor', event: Event): void;
    /** Cambia collezione: le colonne ripartono dai default della nuova. */
    setTableCollection(key: string): void;
    updateColumn(index: number, patch: Partial<DynamicTableColumn>): void;
    addColumn(): void;
    removeColumn(index: number): void;
    private defaultColumnsFor;
    get imageLayout(): string;
    get imageWidthPercent(): number;
    setImageLayout(layout: string): void;
    setImageWidth(value: number): void;
    onBodyImageSelected(event: Event): void;
    private insertBodyImage;
    /**
     * Ridimensiona a max 1400px di larghezza. Le foto (jpeg) restano jpeg
     * (qualità 0.85) per contenere il peso del data-URL nel template.
     */
    private resizeBodyImageToDataUrl;
    /**
     * Come clamp, ma campo vuoto/non numerico → null (= "automatico": il
     * renderer usa il default del foglio/contenuto). Per gli input numerici
     * facoltativi della tabella dinamica.
     */
    clampOrNull(value: number | string | null | undefined, min: number, max: number): number | null;
    clamp(value: number, min: number, max: number): number;
    patchSettings(patch: Partial<TemplatePageSettings>): void;
    removeLogo(): void;
    onLogoSelected(event: Event): void;
    private applyLogo;
    /** Ridimensiona a max 240px di altezza mantenendo le proporzioni. */
    private resizeToDataUrl;
    private showLogoError;
    static ɵfac: i0.ɵɵFactoryDeclaration<TemplateEditorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TemplateEditorComponent, "app-template-editor", never, { "content": { "alias": "content"; "required": false; }; "pageSettings": { "alias": "pageSettings"; "required": false; }; "mergeFields": { "alias": "mergeFields"; "required": false; }; "collections": { "alias": "collections"; "required": false; }; }, { "contentChange": "contentChange"; "pageSettingsChange": "pageSettingsChange"; }, never, never, true, never>;
}

export { TemplateEditorComponent };
