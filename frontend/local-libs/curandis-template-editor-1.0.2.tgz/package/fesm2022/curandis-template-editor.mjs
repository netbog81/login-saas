import { templateContentCss, DEFAULT_PAGE_SETTINGS, TEMPLATE_FONT_OPTIONS, logoBlockCss, templateExtensions, DYNAMIC_TABLE_DEFAULTS } from '@curandis/template-core';
export * from '@curandis/template-core';
import * as i0 from '@angular/core';
import { EventEmitter, ViewChild, Output, Input, ViewEncapsulation, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i3 from '@angular/forms';
import { FormsModule } from '@angular/forms';
import * as i4 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i5 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i6 from '@angular/material/tooltip';
import { MatTooltipModule } from '@angular/material/tooltip';
import * as i7 from '@angular/material/select';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import * as i8 from '@angular/material/input';
import { MatInputModule } from '@angular/material/input';
import * as i9 from '@angular/material/expansion';
import { MatExpansionModule } from '@angular/material/expansion';
import * as i10 from '@angular/material/divider';
import { MatDividerModule } from '@angular/material/divider';
import * as i1 from '@angular/material/snack-bar';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { Editor } from '@tiptap/core';

/** Dimensione massima del logo dopo il ridimensionamento (base64 nel template). */
const LOGO_MAX_DATAURL_BYTES = 300 * 1024;
const LOGO_RESIZE_MAX_HEIGHT_PX = 240;
/** Limiti per le immagini libere nel corpo del documento. */
const BODY_IMAGE_MAX_DATAURL_BYTES = 500 * 1024;
const BODY_IMAGE_RESIZE_MAX_WIDTH_PX = 1400;
const SHARED_CONTENT_STYLE_ID = 'tpl-shared-content-css';
const A4_HEIGHT_MM = 297;
/** In CSS 1in = 96px per definizione, indipendentemente dallo zoom. */
const mmToPx = (mm) => (mm / 25.4) * 96;
/**
 * Inietta in `document.head` le regole di contenuto del foglio, scopate su
 * `.tpl-page`: sono la stessa stringa che finisce nella pagina di stampa
 * (templateContentCss), quindi le due superfici non possono divergere.
 *
 * Va in `<head>` a runtime — non nei `styles` del componente — sia perché la
 * stringa è calcolata da una funzione, sia per finire dopo Tailwind Preflight
 * e vincere a parità di specificità.
 */
function ensureSharedContentStyles() {
    if (document.getElementById(SHARED_CONTENT_STYLE_ID))
        return;
    const style = document.createElement('style');
    style.id = SHARED_CONTENT_STYLE_ID;
    style.textContent = templateContentCss('.tpl-page');
    document.head.appendChild(style);
}
/**
 * Editor WYSIWYG di template documento (TipTap + Angular Material).
 *
 * Componente RIUSABILE e autocontenuto: comunica solo via Input/Output,
 * nessuna dipendenza da servizi applicativi. La superficie di editing
 * riproduce il foglio A4 con le impostazioni di pagina applicate: ciò che si
 * vede è ciò che verrà stampato (il rendering usa lo stesso HTML/CSS di
 * @curandis/template-core).
 *
 * Con `collections` valorizzato l'editor abilita le tabelle dinamiche:
 * blocchi tabella le cui righe vengono generate dai dati (es. righe fattura),
 * con colori di sfondo alternati configurabili.
 */
class TemplateEditorComponent {
    constructor(zone, cdr, snackBar) {
        this.zone = zone;
        this.cdr = cdr;
        this.snackBar = snackBar;
        /** Documento TipTap JSON iniziale (null → documento vuoto). */
        this.content = null;
        /** Impostazioni pagina (null → default). */
        this.pageSettings = null;
        /** Campi dinamici disponibili per questo tipo di documento. */
        this.mergeFields = [];
        /**
         * Collezioni ripetibili disponibili (es. righe documento). Se vuoto, le
         * tabelle dinamiche non sono proposte (comportamento del clinico).
         */
        this.collections = [];
        this.contentChange = new EventEmitter();
        this.pageSettingsChange = new EventEmitter();
        /** Di quanti mm il contenuto sfora il primo foglio A4 (0 = ci sta). */
        this.overflowMm = 0;
        this.settings = { ...DEFAULT_PAGE_SETTINGS };
        this.fontOptions = TEMPLATE_FONT_OPTIONS;
        /** Dimensioni (pt) selezionabili per il testo evidenziato. */
        this.fontSizes = [8, 9, 10, 11, 12, 14, 16, 18, 20, 24, 28, 32];
    }
    get fieldGroups() {
        const map = new Map();
        for (const f of this.mergeFields) {
            const group = f.group ?? 'Campi';
            const list = map.get(group) ?? [];
            list.push(f);
            map.set(group, list);
        }
        return [...map.entries()].map(([name, fields]) => ({ name, fields }));
    }
    get pagePadding() {
        const s = this.settings;
        return `${s.marginTop}mm ${s.marginRight}mm ${s.marginBottom}mm ${s.marginLeft}mm`;
    }
    /** Fondo dell'area utile del primo foglio, rispetto al bordo della pagina. */
    get pageBreakTop() {
        return `${A4_HEIGHT_MM - this.settings.marginBottom}mm`;
    }
    /**
     * Misura quanto il contenuto sfora l'area utile del primo foglio.
     * La superficie di editing è a scorrimento continuo (`min-height: 297mm`),
     * quindi senza questo controllo un documento troppo lungo sembra entrare
     * in una pagina e poi in stampa se ne prende due.
     */
    scheduleOverflowCheck() {
        this.zone.runOutsideAngular(() => {
            requestAnimationFrame(() => {
                const page = this.pageEl?.nativeElement;
                const pm = this.editorHost?.nativeElement.firstElementChild;
                if (!page || !pm)
                    return;
                const pageTop = page.getBoundingClientRect().top;
                // Non uso il rect di .ProseMirror: ha `min-height` e mentirebbe.
                let contentBottom = pageTop;
                const blocks = Array.from(pm.children).concat(Array.from(page.querySelectorAll('.tpl-logo')));
                for (const el of blocks) {
                    contentBottom = Math.max(contentBottom, el.getBoundingClientRect().bottom);
                }
                const limitPx = mmToPx(A4_HEIGHT_MM - this.settings.marginBottom);
                const overflowPx = contentBottom - pageTop - limitPx;
                const next = overflowPx > 1 ? Math.ceil(overflowPx / mmToPx(1)) : 0;
                if (next !== this.overflowMm) {
                    this.zone.run(() => {
                        this.overflowMm = next;
                        this.cdr.markForCheck();
                    });
                }
            });
        });
    }
    /**
     * Stile del blocco logo: la stessa funzione usata dal rendering di stampa
     * (template-core → logoHtml).
     */
    get logoBlockStyle() {
        return logoBlockCss(this.settings);
    }
    get currentBlock() {
        const e = this.editor;
        if (!e)
            return 'p';
        for (const level of [1, 2, 3]) {
            if (e.isActive('heading', { level }))
                return `h${level}`;
        }
        return 'p';
    }
    /** Dimensione del testo alla selezione corrente ('' = eredita dal foglio). */
    get currentFontSize() {
        return String(this.editor?.getAttributes('textStyle')['fontSize'] ?? '');
    }
    /** Colore del testo alla selezione corrente (default: colore del foglio). */
    get currentTextColor() {
        return String(this.editor?.getAttributes('textStyle')['color'] ?? this.settings.textColor);
    }
    /** Evidenziazione (sfondo testo) alla selezione corrente. */
    get currentHighlight() {
        return String(this.editor?.getAttributes('textStyle')['backgroundColor'] ?? '#ffff00');
    }
    /** Sfondo del paragrafo corrente (banda a tutta larghezza). */
    get currentBandColor() {
        return String(this.editor?.getAttributes('paragraph')['bgColor'] ?? '#e8f5e9');
    }
    // ==================== LIFECYCLE ====================
    ngAfterViewInit() {
        ensureSharedContentStyles();
        if (!this.editorHost)
            return;
        // L'editor va creato fuori da NgZone: ProseMirror aggancia molti listener
        // DOM (mousemove, selection) che altrimenti innescherebbero change
        // detection continua. Gli eventi che ci interessano rientrano in zona
        // esplicitamente.
        this.zone.runOutsideAngular(() => {
            this.editor = new Editor({
                element: this.editorHost.nativeElement,
                extensions: templateExtensions(),
                content: this.content ?? undefined,
                onUpdate: ({ editor }) => {
                    this.zone.run(() => {
                        this.contentChange.emit(editor.getJSON());
                        this.cdr.markForCheck();
                    });
                    this.scheduleOverflowCheck();
                },
                onSelectionUpdate: () => {
                    this.zone.run(() => this.cdr.markForCheck());
                },
            });
        });
        this.scheduleOverflowCheck();
        this.cdr.markForCheck();
    }
    ngOnChanges(changes) {
        if (changes['pageSettings']) {
            this.settings = { ...DEFAULT_PAGE_SETTINGS, ...(this.pageSettings ?? {}) };
        }
        if (changes['content'] && this.editor && this.content) {
            const current = JSON.stringify(this.editor.getJSON());
            const incoming = JSON.stringify(this.content);
            if (current !== incoming) {
                this.editor.commands.setContent(this.content, { emitUpdate: false });
            }
        }
        this.scheduleOverflowCheck();
    }
    ngOnDestroy() {
        this.editor?.destroy();
    }
    // ==================== TOOLBAR ====================
    isActive(what) {
        return this.editor?.isActive(what) ?? false;
    }
    isAligned(dir) {
        return this.editor?.isActive({ textAlign: dir }) ?? false;
    }
    cmd(action) {
        const e = this.editor;
        if (!e)
            return;
        const chain = e.chain().focus();
        switch (action) {
            case 'bold':
                chain.toggleBold().run();
                break;
            case 'italic':
                chain.toggleItalic().run();
                break;
            case 'underline':
                chain.toggleUnderline().run();
                break;
            case 'bulletList':
                chain.toggleBulletList().run();
                break;
            case 'orderedList':
                chain.toggleOrderedList().run();
                break;
            case 'hr':
                chain.setHorizontalRule().run();
                break;
            case 'undo':
                chain.undo().run();
                break;
            case 'redo':
                chain.redo().run();
                break;
        }
        this.cdr.markForCheck();
    }
    align(dir) {
        this.editor?.chain().focus().setTextAlign(dir).run();
        this.cdr.markForCheck();
    }
    /** Applica la dimensione carattere al testo selezionato ('' = ripristina). */
    setFontSize(size) {
        const chain = this.editor?.chain().focus();
        if (!chain)
            return;
        if (size) {
            chain.setFontSize(size).run();
        }
        else {
            chain.unsetFontSize().run();
        }
        this.cdr.markForCheck();
    }
    setTextColor(event) {
        const color = event.target.value;
        this.editor?.chain().focus().setColor(color).run();
        this.cdr.markForCheck();
    }
    setHighlight(event) {
        const color = event.target.value;
        this.editor?.chain().focus().setBackgroundColor(color).run();
        this.cdr.markForCheck();
    }
    setBandColor(event) {
        const bgColor = event.target.value;
        this.editor?.chain().focus().updateAttributes('paragraph', { bgColor }).run();
        this.cdr.markForCheck();
    }
    /** Rimuove colore testo, evidenziazione e sfondo riga dalla selezione. */
    clearColors() {
        this.editor?.chain().focus()
            .unsetColor()
            .unsetBackgroundColor()
            .updateAttributes('paragraph', { bgColor: null })
            .run();
        this.cdr.markForCheck();
    }
    // ==================== LINEA SEPARATRICE ====================
    get currentRuleColor() {
        return String(this.editor?.getAttributes('horizontalRule')['color'] ?? this.settings.accentColor);
    }
    get currentRuleThickness() {
        return Number(this.editor?.getAttributes('horizontalRule')['thickness'] ?? 1);
    }
    // Come patchTable: mai .focus() dalle barre contestuali su NodeSelection
    // (linea/immagine/tabella) — ruberebbe il focus ai controlli del pannello.
    setRuleColor(event) {
        const color = event.target.value;
        this.editor?.chain().updateAttributes('horizontalRule', { color }).run();
        this.cdr.markForCheck();
    }
    resetRuleColor() {
        this.editor?.chain().updateAttributes('horizontalRule', { color: null }).run();
        this.cdr.markForCheck();
    }
    setRuleThickness(thickness) {
        this.editor?.chain().updateAttributes('horizontalRule', { thickness }).run();
        this.cdr.markForCheck();
    }
    setBlock(block) {
        const e = this.editor;
        if (!e)
            return;
        if (block === 'p') {
            e.chain().focus().setParagraph().run();
        }
        else {
            const level = Number(block.replace('h', ''));
            e.chain().focus().setHeading({ level }).run();
        }
        this.cdr.markForCheck();
    }
    insertField(field) {
        this.editor?.chain().focus()
            .insertContent([
            { type: 'mergeField', attrs: { field: field.key, label: field.label } },
            { type: 'text', text: ' ' },
        ])
            .run();
    }
    /** Elimina il nodo selezionato (linea, immagine o tabella dinamica). */
    deleteSelectedNode() {
        this.editor?.chain().focus().deleteSelection().run();
        this.cdr.markForCheck();
    }
    // ==================== BLOCCO CONDIZIONALE ====================
    /** Attributi del blocco condizionale attivo (null se il cursore è fuori). */
    get conditionalAttrs() {
        if (!this.editor?.isActive('conditionalBlock'))
            return null;
        const attrs = this.editor.getAttributes('conditionalBlock');
        if (!attrs || typeof attrs['field'] !== 'string')
            return null;
        return attrs;
    }
    /** Label di un campo cercandolo in tutti i gruppi (per l'etichetta blocco). */
    labelForAnyField(key) {
        for (const g of this.fieldGroups) {
            const f = g.fields.find((x) => x.key === key);
            if (f)
                return f.label;
        }
        return key;
    }
    insertConditionalBlock() {
        const first = this.fieldGroups[0]?.fields[0] ?? this.mergeFields[0];
        if (!first)
            return;
        this.editor?.chain().focus()
            .insertContent([
            {
                type: 'conditionalBlock',
                attrs: { field: first.key, mode: 'notEmpty', label: first.label },
                content: [{ type: 'paragraph' }],
            },
            { type: 'paragraph' },
        ])
            .run();
        this.cdr.markForCheck();
    }
    // Come patchTable: niente .focus() dai pannelli contestuali.
    patchConditional(patch) {
        this.editor?.chain().updateAttributes('conditionalBlock', patch).run();
        this.cdr.markForCheck();
    }
    /** Elimina il blocco condizionale (contenuto incluso). */
    deleteConditionalBlock() {
        this.editor?.chain().focus().deleteNode('conditionalBlock').run();
        this.cdr.markForCheck();
    }
    /** Rimuove SOLO il wrapper condizionale: il contenuto resta nel documento. */
    unwrapConditional() {
        const e = this.editor;
        if (!e)
            return;
        const { $from } = e.state.selection;
        for (let d = $from.depth; d > 0; d--) {
            const node = $from.node(d);
            if (node.type.name === 'conditionalBlock') {
                const pos = $from.before(d);
                const inner = node.content.toJSON() ?? [{ type: 'paragraph' }];
                e.chain().focus()
                    .insertContentAt({ from: pos, to: pos + node.nodeSize }, inner)
                    .run();
                break;
            }
        }
        this.cdr.markForCheck();
    }
    // ==================== TABELLA DINAMICA ====================
    /** Attributi della tabella dinamica selezionata (null se non selezionata). */
    get tableAttrs() {
        if (!this.editor?.isActive('dynamicTable'))
            return null;
        const attrs = this.editor.getAttributes('dynamicTable');
        if (!attrs || !Array.isArray(attrs['columns']))
            return null;
        return attrs;
    }
    /** Definizione della collezione usata dalla tabella selezionata. */
    get tableCollectionFields() {
        const key = this.tableAttrs?.collection;
        return this.collections.find((c) => c.key === key)?.fields ?? [];
    }
    labelForField(key) {
        return this.tableCollectionFields.find((f) => f.key === key)?.label ?? key;
    }
    insertDynamicTable() {
        const def = this.collections[0];
        if (!def)
            return;
        this.editor?.chain().focus()
            .insertContent([
            {
                type: 'dynamicTable',
                attrs: { ...DYNAMIC_TABLE_DEFAULTS, collection: def.key, columns: this.defaultColumnsFor(def) },
            },
            { type: 'paragraph' },
        ])
            .run();
        this.cdr.markForCheck();
    }
    patchTable(patch) {
        // NIENTE .focus(): il pannello di configurazione ha input di testo/numero
        // e il focus tornerebbe all'editor A OGNI KEYSTROKE. Con la tabella in
        // NodeSelection, i caratteri successivi SOSTITUIREBBERO il nodo (tabella
        // cancellata e testo scritto sul foglio). La NodeSelection sopravvive a
        // updateAttributes anche senza focus.
        this.editor?.chain().updateAttributes('dynamicTable', patch).run();
        this.cdr.markForCheck();
    }
    setTableColor(attr, event) {
        this.patchTable({ [attr]: event.target.value });
    }
    /** Cambia collezione: le colonne ripartono dai default della nuova. */
    setTableCollection(key) {
        const def = this.collections.find((c) => c.key === key);
        if (!def)
            return;
        this.patchTable({ collection: key, columns: this.defaultColumnsFor(def) });
    }
    updateColumn(index, patch) {
        const attrs = this.tableAttrs;
        if (!attrs)
            return;
        const columns = attrs.columns.map((c, i) => (i === index ? { ...c, ...patch } : c));
        this.patchTable({ columns });
    }
    addColumn() {
        const attrs = this.tableAttrs;
        if (!attrs)
            return;
        const fields = this.tableCollectionFields;
        if (!fields.length)
            return;
        const used = new Set(attrs.columns.map((c) => c.field));
        const next = fields.find((f) => !used.has(f.key)) ?? fields[0];
        this.patchTable({
            columns: [...attrs.columns, { field: next.key, label: next.label, width: 20, align: 'left' }],
        });
    }
    removeColumn(index) {
        const attrs = this.tableAttrs;
        if (!attrs || attrs.columns.length <= 1)
            return;
        this.patchTable({ columns: attrs.columns.filter((_, i) => i !== index) });
    }
    defaultColumnsFor(def) {
        const fields = def.fields.slice(0, 4);
        const width = Math.max(5, Math.floor(100 / Math.max(1, fields.length)));
        return fields.map((f) => ({ field: f.key, label: f.label, width, align: 'left' }));
    }
    // ==================== IMMAGINI NEL CORPO ====================
    get imageLayout() {
        return String(this.editor?.getAttributes('image')['layout'] ?? 'block-center');
    }
    get imageWidthPercent() {
        return Number(this.editor?.getAttributes('image')['widthPercent'] ?? 50);
    }
    setImageLayout(layout) {
        this.editor?.chain().updateAttributes('image', { layout }).run();
        this.cdr.markForCheck();
    }
    setImageWidth(value) {
        const widthPercent = this.clamp(value, 10, 100);
        // Senza .focus(): digitando nel campo larghezza, il focus rubato +
        // NodeSelection sull'immagine la sostituirebbe col testo digitato.
        this.editor?.chain().updateAttributes('image', { widthPercent }).run();
        this.cdr.markForCheck();
    }
    onBodyImageSelected(event) {
        const input = event.target;
        const file = input.files?.[0];
        input.value = '';
        if (!file)
            return;
        const reader = new FileReader();
        reader.onload = () => {
            const src = reader.result;
            if (file.type === 'image/svg+xml') {
                this.insertBodyImage(src);
                return;
            }
            const img = new Image();
            img.onload = () => {
                this.insertBodyImage(this.resizeBodyImageToDataUrl(img, file.type));
            };
            img.onerror = () => this.showLogoError('Immagine non leggibile');
            img.src = src;
        };
        reader.onerror = () => this.showLogoError('File non leggibile');
        reader.readAsDataURL(file);
    }
    insertBodyImage(dataUrl) {
        if (dataUrl.length > BODY_IMAGE_MAX_DATAURL_BYTES) {
            this.showLogoError('Immagine troppo grande anche dopo il ridimensionamento (max ~500KB)');
            return;
        }
        this.zone.run(() => {
            this.editor?.chain().focus()
                .insertContent({
                type: 'image',
                attrs: { src: dataUrl, widthPercent: 50, layout: 'block-center' },
            })
                .run();
            this.cdr.markForCheck();
        });
    }
    /**
     * Ridimensiona a max 1400px di larghezza. Le foto (jpeg) restano jpeg
     * (qualità 0.85) per contenere il peso del data-URL nel template.
     */
    resizeBodyImageToDataUrl(img, mimeType) {
        const scale = Math.min(1, BODY_IMAGE_RESIZE_MAX_WIDTH_PX / img.naturalWidth);
        const w = Math.round(img.naturalWidth * scale);
        const h = Math.round(img.naturalHeight * scale);
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (!ctx)
            return img.src;
        ctx.drawImage(img, 0, 0, w, h);
        return mimeType === 'image/jpeg'
            ? canvas.toDataURL('image/jpeg', 0.85)
            : canvas.toDataURL('image/png');
    }
    // ==================== IMPOSTAZIONI PAGINA ====================
    clamp(value, min, max) {
        const n = Number(value);
        if (Number.isNaN(n))
            return min;
        return Math.min(max, Math.max(min, n));
    }
    patchSettings(patch) {
        this.settings = { ...this.settings, ...patch };
        this.pageSettingsChange.emit({ ...this.settings });
        this.cdr.markForCheck();
        this.scheduleOverflowCheck();
    }
    removeLogo() {
        this.patchSettings({ logoDataUrl: null });
    }
    onLogoSelected(event) {
        const input = event.target;
        const file = input.files?.[0];
        input.value = '';
        if (!file)
            return;
        const reader = new FileReader();
        reader.onload = () => {
            const src = reader.result;
            // SVG: già vettoriale e piccolo, nessun ridimensionamento
            if (file.type === 'image/svg+xml') {
                this.applyLogo(src);
                return;
            }
            const img = new Image();
            img.onload = () => {
                const dataUrl = this.resizeToDataUrl(img);
                this.applyLogo(dataUrl);
            };
            img.onerror = () => this.showLogoError('Immagine non leggibile');
            img.src = src;
        };
        reader.onerror = () => this.showLogoError('File non leggibile');
        reader.readAsDataURL(file);
    }
    applyLogo(dataUrl) {
        if (dataUrl.length > LOGO_MAX_DATAURL_BYTES) {
            this.showLogoError('Logo troppo grande anche dopo il ridimensionamento (max ~200KB)');
            return;
        }
        this.zone.run(() => this.patchSettings({ logoDataUrl: dataUrl }));
    }
    /** Ridimensiona a max 240px di altezza mantenendo le proporzioni. */
    resizeToDataUrl(img) {
        const scale = Math.min(1, LOGO_RESIZE_MAX_HEIGHT_PX / img.naturalHeight);
        const w = Math.round(img.naturalWidth * scale);
        const h = Math.round(img.naturalHeight * scale);
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (!ctx)
            return img.src;
        ctx.drawImage(img, 0, 0, w, h);
        return canvas.toDataURL('image/png');
    }
    showLogoError(message) {
        this.zone.run(() => this.snackBar.open(message, 'OK', { duration: 5000 }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.26", ngImport: i0, type: TemplateEditorComponent, deps: [{ token: i0.NgZone }, { token: i0.ChangeDetectorRef }, { token: i1.MatSnackBar }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.26", type: TemplateEditorComponent, isStandalone: true, selector: "app-template-editor", inputs: { content: "content", pageSettings: "pageSettings", mergeFields: "mergeFields", collections: "collections" }, outputs: { contentChange: "contentChange", pageSettingsChange: "pageSettingsChange" }, viewQueries: [{ propertyName: "editorHost", first: true, predicate: ["editorHost"], descendants: true }, { propertyName: "pageEl", first: true, predicate: ["pageEl"], descendants: true }], usesOnChanges: true, ngImport: i0, template: `
    <div class="tpl-shell">
      <!-- ==================== AREA EDITOR ==================== -->
      <div class="tpl-main">
        <div class="tpl-toolbar mat-elevation-z1">
          <mat-form-field appearance="outline" class="tpl-block-select" subscriptSizing="dynamic">
            <mat-select [value]="currentBlock" (selectionChange)="setBlock($event.value)">
              <mat-option value="p">Paragrafo</mat-option>
              <mat-option value="h1">Titolo 1</mat-option>
              <mat-option value="h2">Titolo 2</mat-option>
              <mat-option value="h3">Titolo 3</mat-option>
            </mat-select>
          </mat-form-field>

          <mat-form-field appearance="outline" class="tpl-size-select" subscriptSizing="dynamic"
                          matTooltip="Dimensione del testo selezionato">
            <mat-select [value]="currentFontSize" (selectionChange)="setFontSize($event.value)">
              <mat-option value="">Auto</mat-option>
              @for (size of fontSizes; track size) {
                <mat-option [value]="size + 'pt'">{{ size }} pt</mat-option>
              }
            </mat-select>
          </mat-form-field>

          <label class="tpl-text-color" matTooltip="Colore del testo selezionato">
            <mat-icon>format_color_text</mat-icon>
            <input type="color" [value]="currentTextColor" (input)="setTextColor($event)" />
          </label>
          <label class="tpl-text-color" matTooltip="Evidenziazione (sfondo del testo selezionato)">
            <mat-icon>format_color_fill</mat-icon>
            <input type="color" [value]="currentHighlight" (input)="setHighlight($event)" />
          </label>
          <label class="tpl-text-color" matTooltip="Sfondo riga (banda colorata a tutta larghezza)">
            <mat-icon>format_paint</mat-icon>
            <input type="color" [value]="currentBandColor" (input)="setBandColor($event)" />
          </label>
          <button mat-icon-button matTooltip="Rimuovi colori (testo, evidenziazione, sfondo riga)"
                  (click)="clearColors()">
            <mat-icon>format_color_reset</mat-icon>
          </button>

          <span class="tpl-toolbar-sep"></span>

          <button mat-icon-button matTooltip="Grassetto" [class.tpl-active]="isActive('bold')" (click)="cmd('bold')">
            <mat-icon>format_bold</mat-icon>
          </button>
          <button mat-icon-button matTooltip="Corsivo" [class.tpl-active]="isActive('italic')" (click)="cmd('italic')">
            <mat-icon>format_italic</mat-icon>
          </button>
          <button mat-icon-button matTooltip="Sottolineato" [class.tpl-active]="isActive('underline')" (click)="cmd('underline')">
            <mat-icon>format_underlined</mat-icon>
          </button>

          <span class="tpl-toolbar-sep"></span>

          <button mat-icon-button matTooltip="Allinea a sinistra" [class.tpl-active]="isAligned('left')" (click)="align('left')">
            <mat-icon>format_align_left</mat-icon>
          </button>
          <button mat-icon-button matTooltip="Centra" [class.tpl-active]="isAligned('center')" (click)="align('center')">
            <mat-icon>format_align_center</mat-icon>
          </button>
          <button mat-icon-button matTooltip="Allinea a destra" [class.tpl-active]="isAligned('right')" (click)="align('right')">
            <mat-icon>format_align_right</mat-icon>
          </button>
          <button mat-icon-button matTooltip="Giustifica" [class.tpl-active]="isAligned('justify')" (click)="align('justify')">
            <mat-icon>format_align_justify</mat-icon>
          </button>

          <span class="tpl-toolbar-sep"></span>

          <button mat-icon-button matTooltip="Elenco puntato" [class.tpl-active]="isActive('bulletList')" (click)="cmd('bulletList')">
            <mat-icon>format_list_bulleted</mat-icon>
          </button>
          <button mat-icon-button matTooltip="Elenco numerato" [class.tpl-active]="isActive('orderedList')" (click)="cmd('orderedList')">
            <mat-icon>format_list_numbered</mat-icon>
          </button>
          <button mat-icon-button matTooltip="Linea separatrice" (click)="cmd('hr')">
            <mat-icon>horizontal_rule</mat-icon>
          </button>
          <button mat-icon-button matTooltip="Inserisci immagine" (click)="bodyImageInput.click()">
            <mat-icon>image</mat-icon>
          </button>
          @if (collections.length) {
            <button mat-icon-button matTooltip="Inserisci tabella dinamica (le righe arrivano dai dati del documento)"
                    (click)="insertDynamicTable()">
              <mat-icon>table_chart</mat-icon>
            </button>
          }
          <button mat-icon-button
                  matTooltip="Blocco condizionale: il contenuto compare solo se un campo ha valore (es. ritenuta, bollo)"
                  [class.tpl-active]="isActive('conditionalBlock')"
                  (click)="insertConditionalBlock()">
            <mat-icon>rule</mat-icon>
          </button>
          <input #bodyImageInput type="file" accept="image/png,image/jpeg,image/svg+xml"
                 hidden (change)="onBodyImageSelected($event)" />

          <span class="tpl-toolbar-sep"></span>

          <button mat-icon-button matTooltip="Annulla" (click)="cmd('undo')">
            <mat-icon>undo</mat-icon>
          </button>
          <button mat-icon-button matTooltip="Ripristina" (click)="cmd('redo')">
            <mat-icon>redo</mat-icon>
          </button>
        </div>

        <!-- Barra contestuale: visibile quando una linea separatrice è selezionata -->
        @if (isActive('horizontalRule')) {
          <div class="tpl-toolbar tpl-image-toolbar mat-elevation-z1">
            <span class="tpl-image-toolbar-label">
              <mat-icon>horizontal_rule</mat-icon>
              Linea:
            </span>
            <label class="tpl-text-color" matTooltip="Colore della linea">
              <input type="color" [value]="currentRuleColor" (input)="setRuleColor($event)" />
            </label>
            <mat-form-field appearance="outline" class="tpl-thickness-select" subscriptSizing="dynamic">
              <mat-select [value]="currentRuleThickness" (selectionChange)="setRuleThickness($event.value)">
                <mat-option [value]="1">Sottile (1px)</mat-option>
                <mat-option [value]="2">Media (2px)</mat-option>
                <mat-option [value]="3">Spessa (3px)</mat-option>
                <mat-option [value]="5">Molto spessa (5px)</mat-option>
              </mat-select>
            </mat-form-field>
            <button mat-icon-button matTooltip="Colore automatico (colore Titoli del foglio)"
                    (click)="resetRuleColor()">
              <mat-icon>format_color_reset</mat-icon>
            </button>

            <span class="tpl-toolbar-sep"></span>

            <button mat-icon-button color="warn" matTooltip="Elimina linea"
                    (click)="deleteSelectedNode()">
              <mat-icon>delete</mat-icon>
            </button>
          </div>
        }

        <!-- Barra contestuale: visibile quando un'immagine è selezionata -->
        @if (isActive('image')) {
          <div class="tpl-toolbar tpl-image-toolbar mat-elevation-z1">
            <span class="tpl-image-toolbar-label">
              <mat-icon>image</mat-icon>
              Immagine:
            </span>

            <mat-form-field appearance="outline" class="tpl-image-layout-select" subscriptSizing="dynamic">
              <mat-select [value]="imageLayout" (selectionChange)="setImageLayout($event.value)">
                <mat-option value="float-left">A sinistra, testo a fianco</mat-option>
                <mat-option value="float-right">A destra, testo a fianco</mat-option>
                <mat-option value="block-left">Blocco a sinistra</mat-option>
                <mat-option value="block-center">Blocco centrato</mat-option>
                <mat-option value="block-right">Blocco a destra</mat-option>
              </mat-select>
            </mat-form-field>

            <span class="tpl-toolbar-sep"></span>

            <label class="tpl-image-width">
              Larghezza
              <input type="number" min="10" max="100" step="5"
                     [ngModel]="imageWidthPercent"
                     (ngModelChange)="setImageWidth($event)" />
              %
            </label>

            <span class="tpl-toolbar-sep"></span>

            <button mat-icon-button color="warn" matTooltip="Elimina immagine"
                    (click)="deleteSelectedNode()">
              <mat-icon>delete</mat-icon>
            </button>
          </div>
        }

        <!-- Barra contestuale: cursore dentro un blocco condizionale -->
        @if (conditionalAttrs; as c) {
          <div class="tpl-toolbar tpl-image-toolbar mat-elevation-z1">
            <span class="tpl-image-toolbar-label">
              <mat-icon>rule</mat-icon>
              Blocco condizionale:
            </span>
            <mat-form-field appearance="outline" class="tpl-conditional-field-select" subscriptSizing="dynamic"
                            matTooltip="Campo che decide se il blocco compare nel documento">
              <mat-select [value]="c.field"
                          (selectionChange)="patchConditional({ field: $event.value, label: labelForAnyField($event.value) })">
                @for (group of fieldGroups; track group.name) {
                  <mat-optgroup [label]="group.name">
                    @for (f of group.fields; track f.key) {
                      <mat-option [value]="f.key">{{ f.label }}</mat-option>
                    }
                  </mat-optgroup>
                }
              </mat-select>
            </mat-form-field>
            <mat-form-field appearance="outline" class="tpl-conditional-mode-select" subscriptSizing="dynamic">
              <mat-select [value]="c.mode" (selectionChange)="patchConditional({ mode: $event.value })">
                <mat-option value="notEmpty">Mostra se il campo ha valore</mat-option>
                <mat-option value="empty">Mostra se il campo è vuoto</mat-option>
              </mat-select>
            </mat-form-field>

            <span class="tpl-toolbar-sep"></span>

            <button mat-icon-button matTooltip="Rimuovi la condizione (il contenuto resta sempre visibile)"
                    (click)="unwrapConditional()">
              <mat-icon>layers_clear</mat-icon>
            </button>
            <button mat-icon-button color="warn" matTooltip="Elimina blocco e contenuto"
                    (click)="deleteConditionalBlock()">
              <mat-icon>delete</mat-icon>
            </button>
          </div>
        }

        <!-- Barra contestuale + pannello colonne: tabella dinamica selezionata -->
        @if (tableAttrs; as t) {
          <div class="tpl-toolbar tpl-image-toolbar mat-elevation-z1">
            <span class="tpl-image-toolbar-label">
              <mat-icon>table_chart</mat-icon>
              Tabella dinamica:
            </span>

            @if (collections.length > 1) {
              <mat-form-field appearance="outline" class="tpl-collection-select" subscriptSizing="dynamic"
                              matTooltip="Origine delle righe">
                <mat-select [value]="t.collection" (selectionChange)="setTableCollection($event.value)">
                  @for (c of collections; track c.key) {
                    <mat-option [value]="c.key">{{ c.label }}</mat-option>
                  }
                </mat-select>
              </mat-form-field>
              <span class="tpl-toolbar-sep"></span>
            }

            <label class="tpl-text-color" matTooltip="Sfondo intestazione">
              <mat-icon>title</mat-icon>
              <input type="color" [value]="t.headerBg" (input)="setTableColor('headerBg', $event)" />
            </label>
            <label class="tpl-text-color" matTooltip="Testo intestazione">
              <mat-icon>format_color_text</mat-icon>
              <input type="color" [value]="t.headerColor" (input)="setTableColor('headerColor', $event)" />
            </label>

            <span class="tpl-toolbar-sep"></span>

            <label class="tpl-text-color" matTooltip="Sfondo righe dispari (1ª, 3ª, 5ª…)">
              <span class="tpl-stripe-label">1·3</span>
              <input type="color" [value]="t.oddRowBg ?? '#ffffff'" (input)="setTableColor('oddRowBg', $event)" />
            </label>
            <label class="tpl-text-color" matTooltip="Sfondo righe pari (2ª, 4ª, 6ª…)">
              <span class="tpl-stripe-label">2·4</span>
              <input type="color" [value]="t.evenRowBg ?? '#ffffff'" (input)="setTableColor('evenRowBg', $event)" />
            </label>
            <button mat-icon-button matTooltip="Rimuovi gli sfondi delle righe"
                    (click)="patchTable({ oddRowBg: null, evenRowBg: null })">
              <mat-icon>format_color_reset</mat-icon>
            </button>

            <span class="tpl-toolbar-sep"></span>

            <mat-form-field appearance="outline" class="tpl-borders-select" subscriptSizing="dynamic"
                            matTooltip="Bordi della tabella">
              <mat-select [value]="t.borders" (selectionChange)="patchTable({ borders: $event.value })">
                <mat-option value="none">Senza bordi</mat-option>
                <mat-option value="rows">Righe orizzontali</mat-option>
                <mat-option value="grid">Griglia completa</mat-option>
              </mat-select>
            </mat-form-field>
            <label class="tpl-text-color" matTooltip="Colore bordi">
              <mat-icon>border_color</mat-icon>
              <input type="color" [value]="t.borderColor" (input)="setTableColor('borderColor', $event)" />
            </label>

            <span class="tpl-toolbar-sep"></span>

            <button mat-icon-button color="warn" matTooltip="Elimina tabella"
                    (click)="deleteSelectedNode()">
              <mat-icon>delete</mat-icon>
            </button>
          </div>

          <div class="tpl-table-columns mat-elevation-z1">
            @for (col of t.columns; track $index) {
              <div class="tpl-table-col-row">
                <span class="tpl-table-col-index">{{ $index + 1 }}</span>
                <mat-form-field appearance="outline" class="tpl-col-field" subscriptSizing="dynamic">
                  <mat-label>Campo</mat-label>
                  <mat-select [value]="col.field"
                              (selectionChange)="updateColumn($index, { field: $event.value, label: labelForField($event.value) })">
                    @for (f of tableCollectionFields; track f.key) {
                      <mat-option [value]="f.key">{{ f.label }}</mat-option>
                    }
                  </mat-select>
                </mat-form-field>
                <mat-form-field appearance="outline" class="tpl-col-label" subscriptSizing="dynamic">
                  <mat-label>Intestazione</mat-label>
                  <input matInput [ngModel]="col.label"
                         (ngModelChange)="updateColumn($index, { label: $event })" />
                </mat-form-field>
                <mat-form-field appearance="outline" class="tpl-col-width" subscriptSizing="dynamic"
                                matTooltip="Larghezza relativa (normalizzata a 100)">
                  <mat-label>Larg.</mat-label>
                  <input matInput type="number" min="5" max="90"
                         [ngModel]="col.width"
                         (ngModelChange)="updateColumn($index, { width: clamp($event, 5, 90) })" />
                </mat-form-field>
                <mat-form-field appearance="outline" class="tpl-col-align" subscriptSizing="dynamic">
                  <mat-label>Allinea</mat-label>
                  <mat-select [value]="col.align" (selectionChange)="updateColumn($index, { align: $event.value })">
                    <mat-option value="left">Sinistra</mat-option>
                    <mat-option value="center">Centro</mat-option>
                    <mat-option value="right">Destra</mat-option>
                  </mat-select>
                </mat-form-field>
                <button mat-icon-button matTooltip="Rimuovi colonna"
                        [disabled]="t.columns.length <= 1" (click)="removeColumn($index)">
                  <mat-icon>close</mat-icon>
                </button>
              </div>
            }
            <button mat-stroked-button (click)="addColumn()">
              <mat-icon>add</mat-icon>
              Aggiungi colonna
            </button>
          </div>
        }

        @if (overflowMm > 0) {
          <div class="tpl-overflow-warn">
            <mat-icon>warning</mat-icon>
            Il contenuto supera l'altezza di un foglio A4 di circa {{ overflowMm }} mm:
            in stampa finirà su una seconda pagina. Togli una riga vuota o riduci il margine inferiore.
          </div>
        }

        <div class="tpl-page-scroll">
          <div #pageEl class="tpl-page"
               [style.backgroundColor]="settings.backgroundColor"
               [style.padding]="pagePadding"
               [style.fontFamily]="settings.fontFamily"
               [style.fontSize.pt]="settings.fontSize"
               [style.color]="settings.textColor"
               [style.--tpl-accent]="settings.accentColor">
            <!-- Dove il browser spezzerà il foglio in stampa. Senza questo
                 riferimento la superficie di editing cresce all'infinito e
                 non mostra mai che il documento non entra in una pagina. -->
            <div class="tpl-page-break" [style.top]="pageBreakTop" aria-hidden="true">
              <span>fine pagina 1</span>
            </div>
            @if (settings.logoDataUrl) {
              <div class="tpl-logo" [ngStyle]="logoBlockStyle">
                <img [src]="settings.logoDataUrl" [style.height.px]="settings.logoHeight" alt="Logo" />
              </div>
            }
            <div #editorHost class="tpl-editor-host"></div>
          </div>
        </div>
      </div>

      <!-- ==================== SIDEBAR ==================== -->
      <aside class="tpl-sidebar">
        <mat-accordion multi>
          <mat-expansion-panel expanded>
            <mat-expansion-panel-header>
              <mat-panel-title>
                <mat-icon class="tpl-panel-icon">data_object</mat-icon>
                Campi dinamici
              </mat-panel-title>
            </mat-expansion-panel-header>
            <p class="tpl-hint">
              Clicca un campo per inserirlo nel punto in cui si trova il cursore.
              Alla generazione verrà sostituito col dato reale.
            </p>
            @for (group of fieldGroups; track group.name) {
              <div class="tpl-field-group">
                <div class="tpl-field-group-name">{{ group.name }}</div>
                <div class="tpl-field-chips">
                  @for (f of group.fields; track f.key) {
                    <button type="button" class="tpl-field-chip"
                            [matTooltip]="f.example ? 'Es.: ' + f.example : ''"
                            (click)="insertField(f)">
                      {{ f.label }}
                    </button>
                  }
                </div>
              </div>
            }
          </mat-expansion-panel>

          <mat-expansion-panel expanded>
            <mat-expansion-panel-header>
              <mat-panel-title>
                <mat-icon class="tpl-panel-icon">palette</mat-icon>
                Aspetto del foglio
              </mat-panel-title>
            </mat-expansion-panel-header>

            <!-- Logo -->
            <div class="tpl-setting-label">Logo</div>
            @if (settings.logoDataUrl) {
              <div class="tpl-logo-row">
                <img [src]="settings.logoDataUrl" alt="Logo" class="tpl-logo-thumb" />
                <button mat-icon-button color="warn" matTooltip="Rimuovi logo" (click)="removeLogo()">
                  <mat-icon>delete</mat-icon>
                </button>
              </div>
              <mat-form-field appearance="outline" class="tpl-w100" subscriptSizing="dynamic">
                <mat-label>Altezza logo (px)</mat-label>
                <input matInput type="number" min="24" max="200"
                       [ngModel]="settings.logoHeight"
                       (ngModelChange)="patchSettings({ logoHeight: clamp($event, 24, 200) })" />
              </mat-form-field>
              <mat-form-field appearance="outline" class="tpl-w100" subscriptSizing="dynamic">
                <mat-label>Posizione logo</mat-label>
                <mat-select [ngModel]="settings.logoAlignment"
                            (ngModelChange)="patchSettings({ logoAlignment: $event })">
                  <mat-option value="left">Sinistra (testo sotto)</mat-option>
                  <mat-option value="center">Centro (testo sotto)</mat-option>
                  <mat-option value="right">Destra (testo sotto)</mat-option>
                  <mat-option value="float-left">Sinistra, testo a fianco</mat-option>
                  <mat-option value="float-right">Destra, testo a fianco</mat-option>
                </mat-select>
              </mat-form-field>
            } @else {
              <button mat-stroked-button class="tpl-w100" (click)="logoInput.click()">
                <mat-icon>add_photo_alternate</mat-icon>
                Carica logo
              </button>
            }
            <input #logoInput type="file" accept="image/png,image/jpeg,image/svg+xml"
                   hidden (change)="onLogoSelected($event)" />

            <mat-divider class="tpl-divider"></mat-divider>

            <!-- Font -->
            <mat-form-field appearance="outline" class="tpl-w100" subscriptSizing="dynamic">
              <mat-label>Carattere</mat-label>
              <mat-select [ngModel]="settings.fontFamily"
                          (ngModelChange)="patchSettings({ fontFamily: $event })">
                @for (f of fontOptions; track f.value) {
                  <mat-option [value]="f.value" [style.fontFamily]="f.value">{{ f.label }}</mat-option>
                }
              </mat-select>
            </mat-form-field>
            <mat-form-field appearance="outline" class="tpl-w100" subscriptSizing="dynamic">
              <mat-label>Dimensione testo base (pt)</mat-label>
              <input matInput type="number" min="8" max="16"
                     [ngModel]="settings.fontSize"
                     (ngModelChange)="patchSettings({ fontSize: clamp($event, 8, 16) })" />
            </mat-form-field>

            <!-- Colori -->
            <div class="tpl-color-row">
              <label>Testo
                <input type="color" [ngModel]="settings.textColor"
                       (ngModelChange)="patchSettings({ textColor: $event })" />
              </label>
              <label>Titoli
                <input type="color" [ngModel]="settings.accentColor"
                       (ngModelChange)="patchSettings({ accentColor: $event })" />
              </label>
              <label>Sfondo
                <input type="color" [ngModel]="settings.backgroundColor"
                       (ngModelChange)="patchSettings({ backgroundColor: $event })" />
              </label>
            </div>

            <mat-divider class="tpl-divider"></mat-divider>

            <!-- Margini -->
            <div class="tpl-setting-label">Margini pagina (mm)</div>
            <div class="tpl-margin-grid">
              <mat-form-field appearance="outline" subscriptSizing="dynamic">
                <mat-label>Sopra</mat-label>
                <input matInput type="number" min="5" max="50"
                       [ngModel]="settings.marginTop"
                       (ngModelChange)="patchSettings({ marginTop: clamp($event, 5, 50) })" />
              </mat-form-field>
              <mat-form-field appearance="outline" subscriptSizing="dynamic">
                <mat-label>Sotto</mat-label>
                <input matInput type="number" min="5" max="50"
                       [ngModel]="settings.marginBottom"
                       (ngModelChange)="patchSettings({ marginBottom: clamp($event, 5, 50) })" />
              </mat-form-field>
              <mat-form-field appearance="outline" subscriptSizing="dynamic">
                <mat-label>Sinistra</mat-label>
                <input matInput type="number" min="5" max="50"
                       [ngModel]="settings.marginLeft"
                       (ngModelChange)="patchSettings({ marginLeft: clamp($event, 5, 50) })" />
              </mat-form-field>
              <mat-form-field appearance="outline" subscriptSizing="dynamic">
                <mat-label>Destra</mat-label>
                <input matInput type="number" min="5" max="50"
                       [ngModel]="settings.marginRight"
                       (ngModelChange)="patchSettings({ marginRight: clamp($event, 5, 50) })" />
              </mat-form-field>
            </div>
          </mat-expansion-panel>
        </mat-accordion>
      </aside>
    </div>
  `, isInline: true, styles: [".tpl-shell{display:flex;gap:16px;align-items:flex-start;width:100%}.tpl-main{flex:1 1 640px;min-width:0}.tpl-sidebar{flex:0 0 300px;max-width:300px}.tpl-toolbar{display:flex;align-items:center;flex-wrap:wrap;gap:2px;padding:4px 8px;border-radius:8px;background:var(--mat-sys-surface-container, #f5f5f5);position:sticky;top:0;z-index:5}.tpl-toolbar-sep{width:1px;height:24px;background:#0000001f;margin:0 6px}.tpl-block-select{width:130px}.tpl-block-select .mat-mdc-text-field-wrapper{height:40px}.tpl-size-select{width:92px}.tpl-size-select .mat-mdc-text-field-wrapper{height:40px}.tpl-text-color{display:inline-flex;align-items:center;gap:2px;cursor:pointer;padding:0 4px}.tpl-text-color mat-icon{color:#000000a6}.tpl-text-color input[type=color]{width:28px;height:28px;border:1px solid rgba(0,0,0,.2);border-radius:4px;padding:1px;background:none;cursor:pointer}.tpl-image-toolbar{margin-top:6px;background:#fff8e1}.tpl-image-toolbar-label{display:flex;align-items:center;gap:6px;font-size:13px;color:#000000a6;margin-right:4px}.tpl-image-layout-select{width:230px}.tpl-image-layout-select .mat-mdc-text-field-wrapper{height:40px}.tpl-thickness-select{width:170px}.tpl-thickness-select .mat-mdc-text-field-wrapper{height:40px}.tpl-collection-select{width:200px}.tpl-collection-select .mat-mdc-text-field-wrapper{height:40px}.tpl-borders-select{width:180px}.tpl-borders-select .mat-mdc-text-field-wrapper{height:40px}.tpl-stripe-label{font:600 11px/1 Roboto,sans-serif;color:#000000a6;letter-spacing:.5px}.tpl-image-width{display:flex;align-items:center;gap:6px;font-size:13px;color:#000000a6}.tpl-image-width input{width:64px;padding:6px 8px;border:1px solid rgba(0,0,0,.25);border-radius:6px;font-family:inherit}button.tpl-active{background:#3f51b524;border-radius:8px}.tpl-table-columns{margin-top:6px;padding:8px 12px;border-radius:8px;background:#fff8e1;display:flex;flex-direction:column;gap:8px;align-items:flex-start}.tpl-table-col-row{display:flex;align-items:center;gap:8px;width:100%;flex-wrap:wrap}.tpl-table-col-index{flex:none;width:18px;font:600 12px/1 Roboto,sans-serif;color:#0000008c;text-align:right}.tpl-col-field{width:220px}.tpl-col-field .mat-mdc-text-field-wrapper{height:44px}.tpl-col-label{flex:1 1 160px;min-width:140px}.tpl-col-label .mat-mdc-text-field-wrapper{height:44px}.tpl-col-width{width:84px}.tpl-col-width .mat-mdc-text-field-wrapper{height:44px}.tpl-col-align{width:120px}.tpl-col-align .mat-mdc-text-field-wrapper{height:44px}.tpl-page-scroll{margin-top:12px;overflow-x:auto;padding-bottom:16px}.tpl-page{position:relative;width:210mm;min-height:297mm;margin:0 auto;box-shadow:0 2px 12px #00000040;box-sizing:border-box;line-height:1.5}.tpl-page-break{position:absolute;left:0;right:0;border-top:1px dashed #d32f2f;pointer-events:none}.tpl-page-break span{position:absolute;right:4px;top:2px;font:10px/1 Roboto,sans-serif;letter-spacing:.5px;text-transform:uppercase;color:#d32f2f}.tpl-overflow-warn{display:flex;align-items:center;gap:8px;margin-top:12px;padding:8px 12px;border-radius:6px;background:#fff3e0;border:1px solid #ffb74d;color:#6d4c00;font-size:13px}.tpl-overflow-warn mat-icon{color:#ef6c00;flex:none}.tpl-editor-host .ProseMirror{outline:none;min-height:180mm}.tpl-page .tpl-conditional{position:relative;border:1px dashed #7986cb;border-radius:4px;padding:14px 8px 2px;margin:0 0 .6em}.tpl-page .tpl-conditional:before{content:'Visibile solo se \"' attr(data-conditional-label) '\" ha valore';position:absolute;top:0;left:6px;font:9px/1.4 Roboto,sans-serif;letter-spacing:.4px;text-transform:uppercase;color:#5c6bc0;pointer-events:none}.tpl-page .tpl-conditional[data-conditional-mode=empty]:before{content:'Visibile solo se \"' attr(data-conditional-label) '\" \\e8  vuoto'}.tpl-editor-host .ProseMirror img.ProseMirror-selectednode{outline:2px solid #3f51b5;outline-offset:1px}.tpl-editor-host .ProseMirror hr.ProseMirror-selectednode,.tpl-editor-host .ProseMirror table.ProseMirror-selectednode{outline:2px solid #3f51b5;outline-offset:2px}.tpl-editor-host .ProseMirror table[data-dynamic-table],.tpl-page .merge-field-chip{cursor:default}.ProseMirror-selectednode.merge-field-chip,.merge-field-chip.ProseMirror-selectednode{outline:2px solid #3f51b5}.tpl-panel-icon{margin-right:8px}.tpl-hint{font-size:12px;color:#0009;margin:4px 0 12px}.tpl-field-group{margin-bottom:12px}.tpl-field-group-name{font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.5px;color:#0000008c;margin-bottom:6px}.tpl-field-chips{display:flex;flex-wrap:wrap;gap:6px}.tpl-field-chip{background:#e8eaf6;border:1px solid #9fa8da;border-radius:14px;padding:3px 10px;font-size:12px;cursor:pointer;font-family:inherit}.tpl-field-chip:hover{background:#c5cae9}.tpl-setting-label{font-size:12px;font-weight:600;color:#000000a6;margin:8px 0 6px}.tpl-w100{width:100%;margin-bottom:10px}.tpl-logo-row{display:flex;align-items:center;gap:8px;margin-bottom:10px}.tpl-logo-thumb{max-height:48px;max-width:180px;border:1px solid rgba(0,0,0,.12);border-radius:4px;padding:2px}.tpl-divider{margin:12px 0}.tpl-color-row{display:flex;gap:12px;flex-wrap:wrap}.tpl-color-row label{display:flex;flex-direction:column;font-size:12px;color:#000000a6;gap:4px}.tpl-color-row input[type=color]{width:56px;height:32px;border:1px solid rgba(0,0,0,.2);border-radius:4px;padding:1px;background:none;cursor:pointer}.tpl-margin-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}@media(max-width:1100px){.tpl-shell{flex-direction:column}.tpl-sidebar{flex:1 1 auto;max-width:none;width:100%}}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i3.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i3.NumberValueAccessor, selector: "input[type=number][formControlName],input[type=number][formControl],input[type=number][ngModel]" }, { kind: "directive", type: i3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i3.MinValidator, selector: "input[type=number][min][formControlName],input[type=number][min][formControl],input[type=number][min][ngModel]", inputs: ["min"] }, { kind: "directive", type: i3.MaxValidator, selector: "input[type=number][max][formControlName],input[type=number][max][formControl],input[type=number][max][ngModel]", inputs: ["max"] }, { kind: "directive", type: i3.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i5.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i5.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i6.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "ngmodule", type: MatSelectModule }, { kind: "component", type: i7.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i7.MatLabel, selector: "mat-label" }, { kind: "component", type: i7.MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth", "canSelectNullableOptions"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "component", type: i7.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "component", type: i7.MatOptgroup, selector: "mat-optgroup", inputs: ["label", "disabled"], exportAs: ["matOptgroup"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i8.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "ngmodule", type: MatExpansionModule }, { kind: "directive", type: i9.MatAccordion, selector: "mat-accordion", inputs: ["hideToggle", "displayMode", "togglePosition"], exportAs: ["matAccordion"] }, { kind: "component", type: i9.MatExpansionPanel, selector: "mat-expansion-panel", inputs: ["hideToggle", "togglePosition"], outputs: ["afterExpand", "afterCollapse"], exportAs: ["matExpansionPanel"] }, { kind: "component", type: i9.MatExpansionPanelHeader, selector: "mat-expansion-panel-header", inputs: ["expandedHeight", "collapsedHeight", "tabIndex"] }, { kind: "directive", type: i9.MatExpansionPanelTitle, selector: "mat-panel-title" }, { kind: "ngmodule", type: MatDividerModule }, { kind: "component", type: i10.MatDivider, selector: "mat-divider", inputs: ["vertical", "inset"] }, { kind: "ngmodule", type: MatSnackBarModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.26", ngImport: i0, type: TemplateEditorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-template-editor', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, imports: [
                        CommonModule,
                        FormsModule,
                        MatIconModule,
                        MatButtonModule,
                        MatTooltipModule,
                        MatSelectModule,
                        MatFormFieldModule,
                        MatInputModule,
                        MatExpansionModule,
                        MatDividerModule,
                        MatSnackBarModule,
                    ], template: `
    <div class="tpl-shell">
      <!-- ==================== AREA EDITOR ==================== -->
      <div class="tpl-main">
        <div class="tpl-toolbar mat-elevation-z1">
          <mat-form-field appearance="outline" class="tpl-block-select" subscriptSizing="dynamic">
            <mat-select [value]="currentBlock" (selectionChange)="setBlock($event.value)">
              <mat-option value="p">Paragrafo</mat-option>
              <mat-option value="h1">Titolo 1</mat-option>
              <mat-option value="h2">Titolo 2</mat-option>
              <mat-option value="h3">Titolo 3</mat-option>
            </mat-select>
          </mat-form-field>

          <mat-form-field appearance="outline" class="tpl-size-select" subscriptSizing="dynamic"
                          matTooltip="Dimensione del testo selezionato">
            <mat-select [value]="currentFontSize" (selectionChange)="setFontSize($event.value)">
              <mat-option value="">Auto</mat-option>
              @for (size of fontSizes; track size) {
                <mat-option [value]="size + 'pt'">{{ size }} pt</mat-option>
              }
            </mat-select>
          </mat-form-field>

          <label class="tpl-text-color" matTooltip="Colore del testo selezionato">
            <mat-icon>format_color_text</mat-icon>
            <input type="color" [value]="currentTextColor" (input)="setTextColor($event)" />
          </label>
          <label class="tpl-text-color" matTooltip="Evidenziazione (sfondo del testo selezionato)">
            <mat-icon>format_color_fill</mat-icon>
            <input type="color" [value]="currentHighlight" (input)="setHighlight($event)" />
          </label>
          <label class="tpl-text-color" matTooltip="Sfondo riga (banda colorata a tutta larghezza)">
            <mat-icon>format_paint</mat-icon>
            <input type="color" [value]="currentBandColor" (input)="setBandColor($event)" />
          </label>
          <button mat-icon-button matTooltip="Rimuovi colori (testo, evidenziazione, sfondo riga)"
                  (click)="clearColors()">
            <mat-icon>format_color_reset</mat-icon>
          </button>

          <span class="tpl-toolbar-sep"></span>

          <button mat-icon-button matTooltip="Grassetto" [class.tpl-active]="isActive('bold')" (click)="cmd('bold')">
            <mat-icon>format_bold</mat-icon>
          </button>
          <button mat-icon-button matTooltip="Corsivo" [class.tpl-active]="isActive('italic')" (click)="cmd('italic')">
            <mat-icon>format_italic</mat-icon>
          </button>
          <button mat-icon-button matTooltip="Sottolineato" [class.tpl-active]="isActive('underline')" (click)="cmd('underline')">
            <mat-icon>format_underlined</mat-icon>
          </button>

          <span class="tpl-toolbar-sep"></span>

          <button mat-icon-button matTooltip="Allinea a sinistra" [class.tpl-active]="isAligned('left')" (click)="align('left')">
            <mat-icon>format_align_left</mat-icon>
          </button>
          <button mat-icon-button matTooltip="Centra" [class.tpl-active]="isAligned('center')" (click)="align('center')">
            <mat-icon>format_align_center</mat-icon>
          </button>
          <button mat-icon-button matTooltip="Allinea a destra" [class.tpl-active]="isAligned('right')" (click)="align('right')">
            <mat-icon>format_align_right</mat-icon>
          </button>
          <button mat-icon-button matTooltip="Giustifica" [class.tpl-active]="isAligned('justify')" (click)="align('justify')">
            <mat-icon>format_align_justify</mat-icon>
          </button>

          <span class="tpl-toolbar-sep"></span>

          <button mat-icon-button matTooltip="Elenco puntato" [class.tpl-active]="isActive('bulletList')" (click)="cmd('bulletList')">
            <mat-icon>format_list_bulleted</mat-icon>
          </button>
          <button mat-icon-button matTooltip="Elenco numerato" [class.tpl-active]="isActive('orderedList')" (click)="cmd('orderedList')">
            <mat-icon>format_list_numbered</mat-icon>
          </button>
          <button mat-icon-button matTooltip="Linea separatrice" (click)="cmd('hr')">
            <mat-icon>horizontal_rule</mat-icon>
          </button>
          <button mat-icon-button matTooltip="Inserisci immagine" (click)="bodyImageInput.click()">
            <mat-icon>image</mat-icon>
          </button>
          @if (collections.length) {
            <button mat-icon-button matTooltip="Inserisci tabella dinamica (le righe arrivano dai dati del documento)"
                    (click)="insertDynamicTable()">
              <mat-icon>table_chart</mat-icon>
            </button>
          }
          <button mat-icon-button
                  matTooltip="Blocco condizionale: il contenuto compare solo se un campo ha valore (es. ritenuta, bollo)"
                  [class.tpl-active]="isActive('conditionalBlock')"
                  (click)="insertConditionalBlock()">
            <mat-icon>rule</mat-icon>
          </button>
          <input #bodyImageInput type="file" accept="image/png,image/jpeg,image/svg+xml"
                 hidden (change)="onBodyImageSelected($event)" />

          <span class="tpl-toolbar-sep"></span>

          <button mat-icon-button matTooltip="Annulla" (click)="cmd('undo')">
            <mat-icon>undo</mat-icon>
          </button>
          <button mat-icon-button matTooltip="Ripristina" (click)="cmd('redo')">
            <mat-icon>redo</mat-icon>
          </button>
        </div>

        <!-- Barra contestuale: visibile quando una linea separatrice è selezionata -->
        @if (isActive('horizontalRule')) {
          <div class="tpl-toolbar tpl-image-toolbar mat-elevation-z1">
            <span class="tpl-image-toolbar-label">
              <mat-icon>horizontal_rule</mat-icon>
              Linea:
            </span>
            <label class="tpl-text-color" matTooltip="Colore della linea">
              <input type="color" [value]="currentRuleColor" (input)="setRuleColor($event)" />
            </label>
            <mat-form-field appearance="outline" class="tpl-thickness-select" subscriptSizing="dynamic">
              <mat-select [value]="currentRuleThickness" (selectionChange)="setRuleThickness($event.value)">
                <mat-option [value]="1">Sottile (1px)</mat-option>
                <mat-option [value]="2">Media (2px)</mat-option>
                <mat-option [value]="3">Spessa (3px)</mat-option>
                <mat-option [value]="5">Molto spessa (5px)</mat-option>
              </mat-select>
            </mat-form-field>
            <button mat-icon-button matTooltip="Colore automatico (colore Titoli del foglio)"
                    (click)="resetRuleColor()">
              <mat-icon>format_color_reset</mat-icon>
            </button>

            <span class="tpl-toolbar-sep"></span>

            <button mat-icon-button color="warn" matTooltip="Elimina linea"
                    (click)="deleteSelectedNode()">
              <mat-icon>delete</mat-icon>
            </button>
          </div>
        }

        <!-- Barra contestuale: visibile quando un'immagine è selezionata -->
        @if (isActive('image')) {
          <div class="tpl-toolbar tpl-image-toolbar mat-elevation-z1">
            <span class="tpl-image-toolbar-label">
              <mat-icon>image</mat-icon>
              Immagine:
            </span>

            <mat-form-field appearance="outline" class="tpl-image-layout-select" subscriptSizing="dynamic">
              <mat-select [value]="imageLayout" (selectionChange)="setImageLayout($event.value)">
                <mat-option value="float-left">A sinistra, testo a fianco</mat-option>
                <mat-option value="float-right">A destra, testo a fianco</mat-option>
                <mat-option value="block-left">Blocco a sinistra</mat-option>
                <mat-option value="block-center">Blocco centrato</mat-option>
                <mat-option value="block-right">Blocco a destra</mat-option>
              </mat-select>
            </mat-form-field>

            <span class="tpl-toolbar-sep"></span>

            <label class="tpl-image-width">
              Larghezza
              <input type="number" min="10" max="100" step="5"
                     [ngModel]="imageWidthPercent"
                     (ngModelChange)="setImageWidth($event)" />
              %
            </label>

            <span class="tpl-toolbar-sep"></span>

            <button mat-icon-button color="warn" matTooltip="Elimina immagine"
                    (click)="deleteSelectedNode()">
              <mat-icon>delete</mat-icon>
            </button>
          </div>
        }

        <!-- Barra contestuale: cursore dentro un blocco condizionale -->
        @if (conditionalAttrs; as c) {
          <div class="tpl-toolbar tpl-image-toolbar mat-elevation-z1">
            <span class="tpl-image-toolbar-label">
              <mat-icon>rule</mat-icon>
              Blocco condizionale:
            </span>
            <mat-form-field appearance="outline" class="tpl-conditional-field-select" subscriptSizing="dynamic"
                            matTooltip="Campo che decide se il blocco compare nel documento">
              <mat-select [value]="c.field"
                          (selectionChange)="patchConditional({ field: $event.value, label: labelForAnyField($event.value) })">
                @for (group of fieldGroups; track group.name) {
                  <mat-optgroup [label]="group.name">
                    @for (f of group.fields; track f.key) {
                      <mat-option [value]="f.key">{{ f.label }}</mat-option>
                    }
                  </mat-optgroup>
                }
              </mat-select>
            </mat-form-field>
            <mat-form-field appearance="outline" class="tpl-conditional-mode-select" subscriptSizing="dynamic">
              <mat-select [value]="c.mode" (selectionChange)="patchConditional({ mode: $event.value })">
                <mat-option value="notEmpty">Mostra se il campo ha valore</mat-option>
                <mat-option value="empty">Mostra se il campo è vuoto</mat-option>
              </mat-select>
            </mat-form-field>

            <span class="tpl-toolbar-sep"></span>

            <button mat-icon-button matTooltip="Rimuovi la condizione (il contenuto resta sempre visibile)"
                    (click)="unwrapConditional()">
              <mat-icon>layers_clear</mat-icon>
            </button>
            <button mat-icon-button color="warn" matTooltip="Elimina blocco e contenuto"
                    (click)="deleteConditionalBlock()">
              <mat-icon>delete</mat-icon>
            </button>
          </div>
        }

        <!-- Barra contestuale + pannello colonne: tabella dinamica selezionata -->
        @if (tableAttrs; as t) {
          <div class="tpl-toolbar tpl-image-toolbar mat-elevation-z1">
            <span class="tpl-image-toolbar-label">
              <mat-icon>table_chart</mat-icon>
              Tabella dinamica:
            </span>

            @if (collections.length > 1) {
              <mat-form-field appearance="outline" class="tpl-collection-select" subscriptSizing="dynamic"
                              matTooltip="Origine delle righe">
                <mat-select [value]="t.collection" (selectionChange)="setTableCollection($event.value)">
                  @for (c of collections; track c.key) {
                    <mat-option [value]="c.key">{{ c.label }}</mat-option>
                  }
                </mat-select>
              </mat-form-field>
              <span class="tpl-toolbar-sep"></span>
            }

            <label class="tpl-text-color" matTooltip="Sfondo intestazione">
              <mat-icon>title</mat-icon>
              <input type="color" [value]="t.headerBg" (input)="setTableColor('headerBg', $event)" />
            </label>
            <label class="tpl-text-color" matTooltip="Testo intestazione">
              <mat-icon>format_color_text</mat-icon>
              <input type="color" [value]="t.headerColor" (input)="setTableColor('headerColor', $event)" />
            </label>

            <span class="tpl-toolbar-sep"></span>

            <label class="tpl-text-color" matTooltip="Sfondo righe dispari (1ª, 3ª, 5ª…)">
              <span class="tpl-stripe-label">1·3</span>
              <input type="color" [value]="t.oddRowBg ?? '#ffffff'" (input)="setTableColor('oddRowBg', $event)" />
            </label>
            <label class="tpl-text-color" matTooltip="Sfondo righe pari (2ª, 4ª, 6ª…)">
              <span class="tpl-stripe-label">2·4</span>
              <input type="color" [value]="t.evenRowBg ?? '#ffffff'" (input)="setTableColor('evenRowBg', $event)" />
            </label>
            <button mat-icon-button matTooltip="Rimuovi gli sfondi delle righe"
                    (click)="patchTable({ oddRowBg: null, evenRowBg: null })">
              <mat-icon>format_color_reset</mat-icon>
            </button>

            <span class="tpl-toolbar-sep"></span>

            <mat-form-field appearance="outline" class="tpl-borders-select" subscriptSizing="dynamic"
                            matTooltip="Bordi della tabella">
              <mat-select [value]="t.borders" (selectionChange)="patchTable({ borders: $event.value })">
                <mat-option value="none">Senza bordi</mat-option>
                <mat-option value="rows">Righe orizzontali</mat-option>
                <mat-option value="grid">Griglia completa</mat-option>
              </mat-select>
            </mat-form-field>
            <label class="tpl-text-color" matTooltip="Colore bordi">
              <mat-icon>border_color</mat-icon>
              <input type="color" [value]="t.borderColor" (input)="setTableColor('borderColor', $event)" />
            </label>

            <span class="tpl-toolbar-sep"></span>

            <button mat-icon-button color="warn" matTooltip="Elimina tabella"
                    (click)="deleteSelectedNode()">
              <mat-icon>delete</mat-icon>
            </button>
          </div>

          <div class="tpl-table-columns mat-elevation-z1">
            @for (col of t.columns; track $index) {
              <div class="tpl-table-col-row">
                <span class="tpl-table-col-index">{{ $index + 1 }}</span>
                <mat-form-field appearance="outline" class="tpl-col-field" subscriptSizing="dynamic">
                  <mat-label>Campo</mat-label>
                  <mat-select [value]="col.field"
                              (selectionChange)="updateColumn($index, { field: $event.value, label: labelForField($event.value) })">
                    @for (f of tableCollectionFields; track f.key) {
                      <mat-option [value]="f.key">{{ f.label }}</mat-option>
                    }
                  </mat-select>
                </mat-form-field>
                <mat-form-field appearance="outline" class="tpl-col-label" subscriptSizing="dynamic">
                  <mat-label>Intestazione</mat-label>
                  <input matInput [ngModel]="col.label"
                         (ngModelChange)="updateColumn($index, { label: $event })" />
                </mat-form-field>
                <mat-form-field appearance="outline" class="tpl-col-width" subscriptSizing="dynamic"
                                matTooltip="Larghezza relativa (normalizzata a 100)">
                  <mat-label>Larg.</mat-label>
                  <input matInput type="number" min="5" max="90"
                         [ngModel]="col.width"
                         (ngModelChange)="updateColumn($index, { width: clamp($event, 5, 90) })" />
                </mat-form-field>
                <mat-form-field appearance="outline" class="tpl-col-align" subscriptSizing="dynamic">
                  <mat-label>Allinea</mat-label>
                  <mat-select [value]="col.align" (selectionChange)="updateColumn($index, { align: $event.value })">
                    <mat-option value="left">Sinistra</mat-option>
                    <mat-option value="center">Centro</mat-option>
                    <mat-option value="right">Destra</mat-option>
                  </mat-select>
                </mat-form-field>
                <button mat-icon-button matTooltip="Rimuovi colonna"
                        [disabled]="t.columns.length <= 1" (click)="removeColumn($index)">
                  <mat-icon>close</mat-icon>
                </button>
              </div>
            }
            <button mat-stroked-button (click)="addColumn()">
              <mat-icon>add</mat-icon>
              Aggiungi colonna
            </button>
          </div>
        }

        @if (overflowMm > 0) {
          <div class="tpl-overflow-warn">
            <mat-icon>warning</mat-icon>
            Il contenuto supera l'altezza di un foglio A4 di circa {{ overflowMm }} mm:
            in stampa finirà su una seconda pagina. Togli una riga vuota o riduci il margine inferiore.
          </div>
        }

        <div class="tpl-page-scroll">
          <div #pageEl class="tpl-page"
               [style.backgroundColor]="settings.backgroundColor"
               [style.padding]="pagePadding"
               [style.fontFamily]="settings.fontFamily"
               [style.fontSize.pt]="settings.fontSize"
               [style.color]="settings.textColor"
               [style.--tpl-accent]="settings.accentColor">
            <!-- Dove il browser spezzerà il foglio in stampa. Senza questo
                 riferimento la superficie di editing cresce all'infinito e
                 non mostra mai che il documento non entra in una pagina. -->
            <div class="tpl-page-break" [style.top]="pageBreakTop" aria-hidden="true">
              <span>fine pagina 1</span>
            </div>
            @if (settings.logoDataUrl) {
              <div class="tpl-logo" [ngStyle]="logoBlockStyle">
                <img [src]="settings.logoDataUrl" [style.height.px]="settings.logoHeight" alt="Logo" />
              </div>
            }
            <div #editorHost class="tpl-editor-host"></div>
          </div>
        </div>
      </div>

      <!-- ==================== SIDEBAR ==================== -->
      <aside class="tpl-sidebar">
        <mat-accordion multi>
          <mat-expansion-panel expanded>
            <mat-expansion-panel-header>
              <mat-panel-title>
                <mat-icon class="tpl-panel-icon">data_object</mat-icon>
                Campi dinamici
              </mat-panel-title>
            </mat-expansion-panel-header>
            <p class="tpl-hint">
              Clicca un campo per inserirlo nel punto in cui si trova il cursore.
              Alla generazione verrà sostituito col dato reale.
            </p>
            @for (group of fieldGroups; track group.name) {
              <div class="tpl-field-group">
                <div class="tpl-field-group-name">{{ group.name }}</div>
                <div class="tpl-field-chips">
                  @for (f of group.fields; track f.key) {
                    <button type="button" class="tpl-field-chip"
                            [matTooltip]="f.example ? 'Es.: ' + f.example : ''"
                            (click)="insertField(f)">
                      {{ f.label }}
                    </button>
                  }
                </div>
              </div>
            }
          </mat-expansion-panel>

          <mat-expansion-panel expanded>
            <mat-expansion-panel-header>
              <mat-panel-title>
                <mat-icon class="tpl-panel-icon">palette</mat-icon>
                Aspetto del foglio
              </mat-panel-title>
            </mat-expansion-panel-header>

            <!-- Logo -->
            <div class="tpl-setting-label">Logo</div>
            @if (settings.logoDataUrl) {
              <div class="tpl-logo-row">
                <img [src]="settings.logoDataUrl" alt="Logo" class="tpl-logo-thumb" />
                <button mat-icon-button color="warn" matTooltip="Rimuovi logo" (click)="removeLogo()">
                  <mat-icon>delete</mat-icon>
                </button>
              </div>
              <mat-form-field appearance="outline" class="tpl-w100" subscriptSizing="dynamic">
                <mat-label>Altezza logo (px)</mat-label>
                <input matInput type="number" min="24" max="200"
                       [ngModel]="settings.logoHeight"
                       (ngModelChange)="patchSettings({ logoHeight: clamp($event, 24, 200) })" />
              </mat-form-field>
              <mat-form-field appearance="outline" class="tpl-w100" subscriptSizing="dynamic">
                <mat-label>Posizione logo</mat-label>
                <mat-select [ngModel]="settings.logoAlignment"
                            (ngModelChange)="patchSettings({ logoAlignment: $event })">
                  <mat-option value="left">Sinistra (testo sotto)</mat-option>
                  <mat-option value="center">Centro (testo sotto)</mat-option>
                  <mat-option value="right">Destra (testo sotto)</mat-option>
                  <mat-option value="float-left">Sinistra, testo a fianco</mat-option>
                  <mat-option value="float-right">Destra, testo a fianco</mat-option>
                </mat-select>
              </mat-form-field>
            } @else {
              <button mat-stroked-button class="tpl-w100" (click)="logoInput.click()">
                <mat-icon>add_photo_alternate</mat-icon>
                Carica logo
              </button>
            }
            <input #logoInput type="file" accept="image/png,image/jpeg,image/svg+xml"
                   hidden (change)="onLogoSelected($event)" />

            <mat-divider class="tpl-divider"></mat-divider>

            <!-- Font -->
            <mat-form-field appearance="outline" class="tpl-w100" subscriptSizing="dynamic">
              <mat-label>Carattere</mat-label>
              <mat-select [ngModel]="settings.fontFamily"
                          (ngModelChange)="patchSettings({ fontFamily: $event })">
                @for (f of fontOptions; track f.value) {
                  <mat-option [value]="f.value" [style.fontFamily]="f.value">{{ f.label }}</mat-option>
                }
              </mat-select>
            </mat-form-field>
            <mat-form-field appearance="outline" class="tpl-w100" subscriptSizing="dynamic">
              <mat-label>Dimensione testo base (pt)</mat-label>
              <input matInput type="number" min="8" max="16"
                     [ngModel]="settings.fontSize"
                     (ngModelChange)="patchSettings({ fontSize: clamp($event, 8, 16) })" />
            </mat-form-field>

            <!-- Colori -->
            <div class="tpl-color-row">
              <label>Testo
                <input type="color" [ngModel]="settings.textColor"
                       (ngModelChange)="patchSettings({ textColor: $event })" />
              </label>
              <label>Titoli
                <input type="color" [ngModel]="settings.accentColor"
                       (ngModelChange)="patchSettings({ accentColor: $event })" />
              </label>
              <label>Sfondo
                <input type="color" [ngModel]="settings.backgroundColor"
                       (ngModelChange)="patchSettings({ backgroundColor: $event })" />
              </label>
            </div>

            <mat-divider class="tpl-divider"></mat-divider>

            <!-- Margini -->
            <div class="tpl-setting-label">Margini pagina (mm)</div>
            <div class="tpl-margin-grid">
              <mat-form-field appearance="outline" subscriptSizing="dynamic">
                <mat-label>Sopra</mat-label>
                <input matInput type="number" min="5" max="50"
                       [ngModel]="settings.marginTop"
                       (ngModelChange)="patchSettings({ marginTop: clamp($event, 5, 50) })" />
              </mat-form-field>
              <mat-form-field appearance="outline" subscriptSizing="dynamic">
                <mat-label>Sotto</mat-label>
                <input matInput type="number" min="5" max="50"
                       [ngModel]="settings.marginBottom"
                       (ngModelChange)="patchSettings({ marginBottom: clamp($event, 5, 50) })" />
              </mat-form-field>
              <mat-form-field appearance="outline" subscriptSizing="dynamic">
                <mat-label>Sinistra</mat-label>
                <input matInput type="number" min="5" max="50"
                       [ngModel]="settings.marginLeft"
                       (ngModelChange)="patchSettings({ marginLeft: clamp($event, 5, 50) })" />
              </mat-form-field>
              <mat-form-field appearance="outline" subscriptSizing="dynamic">
                <mat-label>Destra</mat-label>
                <input matInput type="number" min="5" max="50"
                       [ngModel]="settings.marginRight"
                       (ngModelChange)="patchSettings({ marginRight: clamp($event, 5, 50) })" />
              </mat-form-field>
            </div>
          </mat-expansion-panel>
        </mat-accordion>
      </aside>
    </div>
  `, styles: [".tpl-shell{display:flex;gap:16px;align-items:flex-start;width:100%}.tpl-main{flex:1 1 640px;min-width:0}.tpl-sidebar{flex:0 0 300px;max-width:300px}.tpl-toolbar{display:flex;align-items:center;flex-wrap:wrap;gap:2px;padding:4px 8px;border-radius:8px;background:var(--mat-sys-surface-container, #f5f5f5);position:sticky;top:0;z-index:5}.tpl-toolbar-sep{width:1px;height:24px;background:#0000001f;margin:0 6px}.tpl-block-select{width:130px}.tpl-block-select .mat-mdc-text-field-wrapper{height:40px}.tpl-size-select{width:92px}.tpl-size-select .mat-mdc-text-field-wrapper{height:40px}.tpl-text-color{display:inline-flex;align-items:center;gap:2px;cursor:pointer;padding:0 4px}.tpl-text-color mat-icon{color:#000000a6}.tpl-text-color input[type=color]{width:28px;height:28px;border:1px solid rgba(0,0,0,.2);border-radius:4px;padding:1px;background:none;cursor:pointer}.tpl-image-toolbar{margin-top:6px;background:#fff8e1}.tpl-image-toolbar-label{display:flex;align-items:center;gap:6px;font-size:13px;color:#000000a6;margin-right:4px}.tpl-image-layout-select{width:230px}.tpl-image-layout-select .mat-mdc-text-field-wrapper{height:40px}.tpl-thickness-select{width:170px}.tpl-thickness-select .mat-mdc-text-field-wrapper{height:40px}.tpl-collection-select{width:200px}.tpl-collection-select .mat-mdc-text-field-wrapper{height:40px}.tpl-borders-select{width:180px}.tpl-borders-select .mat-mdc-text-field-wrapper{height:40px}.tpl-stripe-label{font:600 11px/1 Roboto,sans-serif;color:#000000a6;letter-spacing:.5px}.tpl-image-width{display:flex;align-items:center;gap:6px;font-size:13px;color:#000000a6}.tpl-image-width input{width:64px;padding:6px 8px;border:1px solid rgba(0,0,0,.25);border-radius:6px;font-family:inherit}button.tpl-active{background:#3f51b524;border-radius:8px}.tpl-table-columns{margin-top:6px;padding:8px 12px;border-radius:8px;background:#fff8e1;display:flex;flex-direction:column;gap:8px;align-items:flex-start}.tpl-table-col-row{display:flex;align-items:center;gap:8px;width:100%;flex-wrap:wrap}.tpl-table-col-index{flex:none;width:18px;font:600 12px/1 Roboto,sans-serif;color:#0000008c;text-align:right}.tpl-col-field{width:220px}.tpl-col-field .mat-mdc-text-field-wrapper{height:44px}.tpl-col-label{flex:1 1 160px;min-width:140px}.tpl-col-label .mat-mdc-text-field-wrapper{height:44px}.tpl-col-width{width:84px}.tpl-col-width .mat-mdc-text-field-wrapper{height:44px}.tpl-col-align{width:120px}.tpl-col-align .mat-mdc-text-field-wrapper{height:44px}.tpl-page-scroll{margin-top:12px;overflow-x:auto;padding-bottom:16px}.tpl-page{position:relative;width:210mm;min-height:297mm;margin:0 auto;box-shadow:0 2px 12px #00000040;box-sizing:border-box;line-height:1.5}.tpl-page-break{position:absolute;left:0;right:0;border-top:1px dashed #d32f2f;pointer-events:none}.tpl-page-break span{position:absolute;right:4px;top:2px;font:10px/1 Roboto,sans-serif;letter-spacing:.5px;text-transform:uppercase;color:#d32f2f}.tpl-overflow-warn{display:flex;align-items:center;gap:8px;margin-top:12px;padding:8px 12px;border-radius:6px;background:#fff3e0;border:1px solid #ffb74d;color:#6d4c00;font-size:13px}.tpl-overflow-warn mat-icon{color:#ef6c00;flex:none}.tpl-editor-host .ProseMirror{outline:none;min-height:180mm}.tpl-page .tpl-conditional{position:relative;border:1px dashed #7986cb;border-radius:4px;padding:14px 8px 2px;margin:0 0 .6em}.tpl-page .tpl-conditional:before{content:'Visibile solo se \"' attr(data-conditional-label) '\" ha valore';position:absolute;top:0;left:6px;font:9px/1.4 Roboto,sans-serif;letter-spacing:.4px;text-transform:uppercase;color:#5c6bc0;pointer-events:none}.tpl-page .tpl-conditional[data-conditional-mode=empty]:before{content:'Visibile solo se \"' attr(data-conditional-label) '\" \\e8  vuoto'}.tpl-editor-host .ProseMirror img.ProseMirror-selectednode{outline:2px solid #3f51b5;outline-offset:1px}.tpl-editor-host .ProseMirror hr.ProseMirror-selectednode,.tpl-editor-host .ProseMirror table.ProseMirror-selectednode{outline:2px solid #3f51b5;outline-offset:2px}.tpl-editor-host .ProseMirror table[data-dynamic-table],.tpl-page .merge-field-chip{cursor:default}.ProseMirror-selectednode.merge-field-chip,.merge-field-chip.ProseMirror-selectednode{outline:2px solid #3f51b5}.tpl-panel-icon{margin-right:8px}.tpl-hint{font-size:12px;color:#0009;margin:4px 0 12px}.tpl-field-group{margin-bottom:12px}.tpl-field-group-name{font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.5px;color:#0000008c;margin-bottom:6px}.tpl-field-chips{display:flex;flex-wrap:wrap;gap:6px}.tpl-field-chip{background:#e8eaf6;border:1px solid #9fa8da;border-radius:14px;padding:3px 10px;font-size:12px;cursor:pointer;font-family:inherit}.tpl-field-chip:hover{background:#c5cae9}.tpl-setting-label{font-size:12px;font-weight:600;color:#000000a6;margin:8px 0 6px}.tpl-w100{width:100%;margin-bottom:10px}.tpl-logo-row{display:flex;align-items:center;gap:8px;margin-bottom:10px}.tpl-logo-thumb{max-height:48px;max-width:180px;border:1px solid rgba(0,0,0,.12);border-radius:4px;padding:2px}.tpl-divider{margin:12px 0}.tpl-color-row{display:flex;gap:12px;flex-wrap:wrap}.tpl-color-row label{display:flex;flex-direction:column;font-size:12px;color:#000000a6;gap:4px}.tpl-color-row input[type=color]{width:56px;height:32px;border:1px solid rgba(0,0,0,.2);border-radius:4px;padding:1px;background:none;cursor:pointer}.tpl-margin-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}@media(max-width:1100px){.tpl-shell{flex-direction:column}.tpl-sidebar{flex:1 1 auto;max-width:none;width:100%}}\n"] }]
        }], ctorParameters: () => [{ type: i0.NgZone }, { type: i0.ChangeDetectorRef }, { type: i1.MatSnackBar }], propDecorators: { content: [{
                type: Input
            }], pageSettings: [{
                type: Input
            }], mergeFields: [{
                type: Input
            }], collections: [{
                type: Input
            }], contentChange: [{
                type: Output
            }], pageSettingsChange: [{
                type: Output
            }], editorHost: [{
                type: ViewChild,
                args: ['editorHost', { static: false }]
            }], pageEl: [{
                type: ViewChild,
                args: ['pageEl', { static: false }]
            }] } });

/**
 * @curandis/template-editor — editor WYSIWYG dei template documento.
 * Ri-esporta anche tutto @curandis/template-core: i consumatori importano
 * modelli, estensioni e utility di rendering da un unico pacchetto.
 */

/**
 * Generated bundle index. Do not edit.
 */

export { TemplateEditorComponent };
//# sourceMappingURL=curandis-template-editor.mjs.map
